package com.firstapp.fuelwisesa;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

public class VehicleActivity extends AppCompatActivity {

    private Button btnAddVehicle;
    private Button btnBackDashboard;

    private LinearLayout vehicleListContainer;
    private LinearLayout emptyVehicleCard;

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle);

        // Connect XML
        btnAddVehicle =
                findViewById(R.id.btnAddVehicle);

        btnBackDashboard =
                findViewById(R.id.btnBackDashboard);

        vehicleListContainer =
                findViewById(R.id.vehicleListContainer);

        emptyVehicleCard =
                findViewById(R.id.emptyVehicleCard);

        // Firebase
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        // Add Vehicle
        btnAddVehicle.setOnClickListener(v -> {

            Intent intent = new Intent(
                    VehicleActivity.this,
                    AddVehicleActivity.class
            );

            startActivity(intent);
        });

        // Back to dashboard
        btnBackDashboard.setOnClickListener(v ->
                finish()
        );
    }

    @Override
    protected void onResume() {
        super.onResume();

        loadVehicles();
    }

    // ---------------------------------------------------------
    // LOAD VEHICLES
    // ---------------------------------------------------------

    private void loadVehicles() {

        FirebaseUser currentUser =
                mAuth.getCurrentUser();

        if (currentUser == null) {

            Toast.makeText(
                    this,
                    "You must be logged in",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        String userId =
                currentUser.getUid();

        clearVehicleCards();

        db.collection("vehicles")
                .whereEqualTo("userId", userId)
                .get()
                .addOnSuccessListener(
                        queryDocumentSnapshots -> {

                            if (queryDocumentSnapshots.isEmpty()) {

                                emptyVehicleCard.setVisibility(
                                        View.VISIBLE
                                );

                                return;
                            }

                            emptyVehicleCard.setVisibility(
                                    View.GONE
                            );

                            for (QueryDocumentSnapshot document
                                    : queryDocumentSnapshots) {

                                String vehicleId =
                                        document.getId();

                                String make =
                                        document.getString(
                                                "make"
                                        );

                                String model =
                                        document.getString(
                                                "model"
                                        );

                                String registration =
                                        document.getString(
                                                "registrationNumber"
                                        );

                                String fuelType =
                                        document.getString(
                                                "fuelType"
                                        );

                                Long year =
                                        document.getLong(
                                                "year"
                                        );

                                addVehicleCard(
                                        vehicleId,
                                        make,
                                        model,
                                        registration,
                                        year,
                                        fuelType
                                );
                            }
                        })
                .addOnFailureListener(e -> {

                    Toast.makeText(
                            VehicleActivity.this,
                            "Could not load vehicles: "
                                    + e.getMessage(),
                            Toast.LENGTH_LONG
                    ).show();
                });
    }

    // ---------------------------------------------------------
    // CLEAR OLD CARDS
    // ---------------------------------------------------------

    private void clearVehicleCards() {

        while (vehicleListContainer
                .getChildCount() > 1) {

            vehicleListContainer
                    .removeViewAt(1);
        }
    }

    // ---------------------------------------------------------
    // CREATE VEHICLE CARD
    // ---------------------------------------------------------

    private void addVehicleCard(
            String vehicleId,
            String make,
            String model,
            String registration,
            Long year,
            String fuelType
    ) {

        LinearLayout card =
                new LinearLayout(this);

        card.setOrientation(
                LinearLayout.VERTICAL
        );

        int padding = dpToPx(20);

        card.setPadding(
                padding,
                padding,
                padding,
                padding
        );

        card.setBackgroundResource(
                R.drawable.bg_dashboard_green
        );

        LinearLayout.LayoutParams cardParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        cardParams.setMargins(
                0,
                0,
                0,
                dpToPx(15)
        );

        card.setLayoutParams(cardParams);

        // -----------------------------------------------------
        // VEHICLE NAME
        // -----------------------------------------------------

        TextView vehicleName =
                new TextView(this);

        String displayName =
                safeText(make)
                        + " "
                        + safeText(model);

        vehicleName.setText(
                displayName.trim()
        );

        vehicleName.setTextSize(19);

        vehicleName.setTextColor(
                Color.parseColor("#263326")
        );

        vehicleName.setTypeface(
                null,
                Typeface.BOLD
        );

        card.addView(vehicleName);

        // -----------------------------------------------------
        // REGISTRATION
        // -----------------------------------------------------

        TextView registrationText =
                new TextView(this);

        registrationText.setText(
                "Registration: "
                        + safeText(registration)
        );

        registrationText.setTextSize(14);

        registrationText.setTextColor(
                Color.parseColor("#657265")
        );

        registrationText.setPadding(
                0,
                dpToPx(8),
                0,
                0
        );

        card.addView(registrationText);

        // -----------------------------------------------------
        // YEAR
        // -----------------------------------------------------

        TextView yearText =
                new TextView(this);

        String yearValue =
                year == null
                        ? "Not specified"
                        : String.valueOf(year);

        yearText.setText(
                "Year: " + yearValue
        );

        yearText.setTextSize(14);

        yearText.setTextColor(
                Color.parseColor("#657265")
        );

        yearText.setPadding(
                0,
                dpToPx(4),
                0,
                0
        );

        card.addView(yearText);

        // -----------------------------------------------------
        // FUEL TYPE
        // -----------------------------------------------------

        TextView fuelText =
                new TextView(this);

        fuelText.setText(
                "Fuel Type: "
                        + safeText(fuelType)
        );

        fuelText.setTextSize(14);

        fuelText.setTextColor(
                Color.parseColor("#657265")
        );

        fuelText.setPadding(
                0,
                dpToPx(4),
                0,
                dpToPx(15)
        );

        card.addView(fuelText);

        // -----------------------------------------------------
        // BUTTON ROW
        // -----------------------------------------------------

        LinearLayout buttonRow =
                new LinearLayout(this);

        buttonRow.setOrientation(
                LinearLayout.HORIZONTAL
        );

        buttonRow.setWeightSum(2f);

        // EDIT BUTTON
        Button btnEdit =
                new Button(this);

        btnEdit.setText("Edit");
        btnEdit.setTextSize(14);
        btnEdit.setTextColor(
                Color.parseColor("#568D48")
        );



        btnEdit.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(
                        Color.parseColor("#FFFFFF")
                )
        );

        LinearLayout.LayoutParams editParams =
                new LinearLayout.LayoutParams(
                        0,
                        dpToPx(52),
                        1f
                );

        editParams.setMargins(
                0,
                0,
                dpToPx(5),
                0
        );

        btnEdit.setLayoutParams(
                editParams
        );

        // DELETE BUTTON
        Button btnDelete =
                new Button(this);

        btnDelete.setText("Delete");
        btnDelete.setTextSize(14);

        btnDelete.setTextColor(
                Color.parseColor("#A65353")
        );



        btnDelete.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(
                        Color.parseColor("#FFF0F0")
                )
        );

        LinearLayout.LayoutParams deleteParams =
                new LinearLayout.LayoutParams(
                        0,
                        dpToPx(52),
                        1f
                );

        deleteParams.setMargins(
                dpToPx(5),
                0,
                0,
                0
        );

        btnDelete.setLayoutParams(
                deleteParams
        );

        // -----------------------------------------------------
        // EDIT CLICK
        // -----------------------------------------------------

        btnEdit.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            VehicleActivity.this,
                            AddVehicleActivity.class
                    );

            intent.putExtra(
                    "EDIT_MODE",
                    true
            );

            intent.putExtra(
                    "VEHICLE_ID",
                    vehicleId
            );

            intent.putExtra(
                    "MAKE",
                    make
            );

            intent.putExtra(
                    "MODEL",
                    model
            );

            intent.putExtra(
                    "REGISTRATION",
                    registration
            );

            intent.putExtra(
                    "YEAR",
                    year == null
                            ? 0L
                            : year
            );

            intent.putExtra(
                    "FUEL_TYPE",
                    fuelType
            );

            startActivity(intent);
        });

        // -----------------------------------------------------
        // DELETE CLICK
        // -----------------------------------------------------

        btnDelete.setOnClickListener(v -> {

            showDeleteConfirmation(
                    vehicleId,
                    displayName.trim()
            );
        });

        buttonRow.addView(btnEdit);
        buttonRow.addView(btnDelete);

        card.addView(buttonRow);

        vehicleListContainer.addView(card);
    }

    // ---------------------------------------------------------
    // DELETE CONFIRMATION
    // ---------------------------------------------------------

    private void showDeleteConfirmation(
            String vehicleId,
            String vehicleName
    ) {

        new AlertDialog.Builder(this)
                .setTitle("Delete Vehicle")
                .setMessage(
                        "Are you sure you want to delete "
                                + vehicleName
                                + "?\n\n"
                                + "This action cannot be undone."
                )
                .setNegativeButton(
                        "Cancel",
                        null
                )
                .setPositiveButton(
                        "Delete",
                        (dialog, which) ->
                                deleteVehicle(vehicleId)
                )
                .show();
    }

    // ---------------------------------------------------------
    // DELETE VEHICLE
    // ---------------------------------------------------------

    private void deleteVehicle(
            String vehicleId
    ) {

        db.collection("vehicles")
                .document(vehicleId)
                .delete()
                .addOnSuccessListener(unused -> {

                    Toast.makeText(
                            VehicleActivity.this,
                            "Vehicle deleted",
                            Toast.LENGTH_SHORT
                    ).show();

                    loadVehicles();
                })
                .addOnFailureListener(e -> {

                    Toast.makeText(
                            VehicleActivity.this,
                            "Could not delete vehicle: "
                                    + e.getMessage(),
                            Toast.LENGTH_LONG
                    ).show();
                });
    }

    // ---------------------------------------------------------
    // HELPERS
    // ---------------------------------------------------------

    private String safeText(
            String value
    ) {

        if (value == null
                || value.trim().isEmpty()) {

            return "Not specified";
        }

        return value;
    }

    private int dpToPx(int dp) {

        float density =
                getResources()
                        .getDisplayMetrics()
                        .density;

        return Math.round(
                dp * density
        );
    }
}