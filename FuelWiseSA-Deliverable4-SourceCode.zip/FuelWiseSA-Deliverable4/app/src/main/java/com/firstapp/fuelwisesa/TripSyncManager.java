
package com.firstapp.fuelwisesa;

import android.content.Context;
import android.util.Log;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class TripSyncManager {

    private static final String TAG = "FuelWiseSync";

    public static void sync(Context context) {
        FirebaseUser user = FirebaseAuth.getInstance()
                .getCurrentUser();

        if (user == null) {
            return;
        }

        final String uid = user.getUid();
        LocalTripStore store = new LocalTripStore(
                context.getApplicationContext());

        try {
            List<JSONObject> pending = store.getForUser(uid);

            for (JSONObject trip : pending) {

                String tripId = trip.getString("tripId");

                Map<String, Object> data = new HashMap<>();
                Iterator<String> keys = trip.keys();

                while (keys.hasNext()) {
                    String key = keys.next();
                    Object value = trip.get(key);

                    if (value != JSONObject.NULL) {
                        data.put(key, value);
                    }
                }

                FirebaseFirestore.getInstance()
                        .collection("trips")
                        .document(tripId)
                        .set(data)
                        .addOnSuccessListener(unused -> {
                            try {
                                store.remove(tripId);
                                Log.i(TAG, "Trip synchronised");
                            } catch (Exception e) {
                                Log.e(TAG,
                                        "Uploaded but local cleanup failed", e);
                            }
                        })
                        .addOnFailureListener(e ->
                                Log.e(TAG, "Trip sync failed", e));
            }

        } catch (Exception e) {
            Log.e(TAG, "Could not read local trips", e);
        }
    }
}

