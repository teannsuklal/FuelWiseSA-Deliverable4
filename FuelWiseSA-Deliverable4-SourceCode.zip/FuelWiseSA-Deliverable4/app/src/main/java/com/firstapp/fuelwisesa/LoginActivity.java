
package com.firstapp.fuelwisesa;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LoginActivity extends AppCompatActivity {

    private EditText etLoginEmail;
    private EditText etLoginPassword;

    private Button btnLogin;
    private Button btnGoRegister;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etLoginEmail = findViewById(R.id.etLoginEmail);
        etLoginPassword = findViewById(R.id.etLoginPassword);

        btnLogin = findViewById(R.id.btnLogin);
        btnGoRegister = findViewById(R.id.btnGoRegister);

        mAuth = FirebaseAuth.getInstance();

        // LOGIN
        btnLogin.setOnClickListener(v -> loginUser());

        // REGISTER
        btnGoRegister.setOnClickListener(v -> {
            Intent intent = new Intent(
                    LoginActivity.this,
                    RegisterActivity.class
            );
            startActivity(intent);
        });
    }

    private void loginUser() {

        String email = etLoginEmail.getText()
                .toString().trim();

        String password = etLoginPassword.getText()
                .toString().trim();

        if (email.isEmpty()) {
            etLoginEmail.setError("Enter your email");
            etLoginEmail.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            etLoginPassword.setError("Enter your password");
            etLoginPassword.requestFocus();
            return;
        }

        btnLogin.setEnabled(false);
        btnLogin.setText("Logging in...");

        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {

                    btnLogin.setEnabled(true);
                    btnLogin.setText("Login");

                    if (task.isSuccessful()) {

                        FirebaseUser currentUser =
                                mAuth.getCurrentUser();

                        if (currentUser == null) {
                            Toast.makeText(
                                    this,
                                    "Could not verify your account",
                                    Toast.LENGTH_LONG
                            ).show();
                            return;
                        }

                        // Sync only trips belonging to
                        // the authenticated Firebase user.
                        TripSyncManager.sync(
                                getApplicationContext()
                        );

                        Toast.makeText(
                                this,
                                "Login successful",
                                Toast.LENGTH_SHORT
                        ).show();

                        Intent intent = new Intent(
                                LoginActivity.this,
                                DashboardActivity.class
                        );

                        startActivity(intent);
                        finish();

                    } else {

                        String message = task.getException() == null
                                ? "Login failed. Please try again."
                                : task.getException().getMessage();

                        Toast.makeText(
                                this,
                                message,
                                Toast.LENGTH_LONG
                        ).show();
                    }
                });
    }
}
