package com.firstapp.fuelwisesa;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class TripHistoryActivity extends AppCompatActivity {

    private TextView tvTotalTripDistance;
    private TextView tvTripCount;

    private LinearLayout tripListContainer;
    private LinearLayout emptyTripCard;

    private Button btnAddTripFromHistory;
    private Button btnBackFromTripHistory;

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trip_history);

        tvTotalTripDistance =
                findViewById(R.id.tvTotalTripDistance);

        tvTripCount =
                findViewById(R.id.tvTripCount);

        tripListContainer =
                findViewById(R.id.tripListContainer);

        emptyTripCard =
                findViewById(R.id.emptyTripCard);

        btnAddTripFromHistory =
                findViewById(R.id.btnAddTripFromHistory);

        btnBackFromTripHistory =
                findViewById(R.id.btnBackFromTripHistory);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        btnAddTripFromHistory.setOnClickListener(v -> {

            Intent intent = new Intent(
                    TripHistoryActivity.this,
                    AddTripActivity.class
            );

            startActivity(intent);
        });

        btnBackFromTripHistory.setOnClickListener(v -> finish());
    }

    @Override
    protected void onResume() {
        super.onResume();

        loadTrips();
    }

    private void loadTrips() {

        FirebaseUser currentUser = mAuth.getCurrentUser();

        if (currentUser == null) {

            Toast.makeText(
                    this,
                    "You must be logged in",
                    Toast.LENGTH_SHORT
            ).show();

            finish();
            return;
        }

        clearTripCards();

        db.collection("trips")
                .whereEqualTo(
                        "userId",
                        currentUser.getUid()
                )
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {

                    if (queryDocumentSnapshots.isEmpty()) {

                        emptyTripCard.setVisibility(View.VISIBLE);

                        tvTotalTripDistance.setText("0.0 km");
                        tvTripCount.setText("0 trips recorded");

                        return;
                    }

                    emptyTripCard.setVisibility(View.GONE);

                    List<TripItem> trips = new ArrayList<>();

                    double totalDistance = 0.0;

                    for (QueryDocumentSnapshot document
                            : queryDocumentSnapshots) {

                        String vehicleName =
                                document.getString("vehicleName");

                        String startLocation =
                                document.getString("startLocation");

                        String endLocation =
                                document.getString("endLocation");

                        String date =
                                document.getString("date");

                        Double distance =
                                document.getDouble("distanceKm");

                        Long createdAt =
                                document.getLong("createdAt");

                        if (distance == null) {
                            distance = 0.0;
                        }

                        if (createdAt == null) {
                            createdAt = 0L;
                        }

                        totalDistance += distance;

                        trips.add(
                                new TripItem(
                                        vehicleName,
                                        startLocation,
                                        endLocation,
                                        date,
                                        distance,
                                        createdAt
                                )
                        );
                    }

                    // Newest saved trip first
                    Collections.sort(
                            trips,
                            Comparator.comparingLong(
                                    TripItem::getCreatedAt
                            ).reversed()
                    );

                    for (TripItem trip : trips) {

                        addTripCard(
                                trip.vehicleName,
                                trip.startLocation,
                                trip.endLocation,
                                trip.date,
                                trip.distanceKm
                        );
                    }

                    tvTotalTripDistance.setText(
                            String.format(
                                    Locale.getDefault(),
                                    "%.1f km",
                                    totalDistance
                            )
                    );

                    int tripCount = trips.size();

                    if (tripCount == 1) {
                        tvTripCount.setText("1 trip recorded");
                    } else {
                        tvTripCount.setText(
                                tripCount + " trips recorded"
                        );
                    }
                })
                .addOnFailureListener(e -> {

                    Toast.makeText(
                            TripHistoryActivity.this,
                            "Could not load trips: "
                                    + e.getMessage(),
                            Toast.LENGTH_LONG
                    ).show();
                });
    }

    private void clearTripCards() {

        while (tripListContainer.getChildCount() > 1) {
            tripListContainer.removeViewAt(1);
        }
    }

    private void addTripCard(
            String vehicleName,
            String startLocation,
            String endLocation,
            String date,
            double distanceKm
    ) {

        LinearLayout card = new LinearLayout(this);

        card.setOrientation(LinearLayout.VERTICAL);

        int padding = dpToPx(20);

        card.setPadding(
                padding,
                padding,
                padding,
                padding
        );

        card.setBackgroundResource(
                R.drawable.bg_dashboard_blue
        );

        LinearLayout.LayoutParams cardParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        cardParams.setMargins(
                0,
                0,
                0,
                dpToPx(15)
        );

        card.setLayoutParams(cardParams);

        // Vehicle
        TextView vehicleText = new TextView(this);

        vehicleText.setText(
                safeText(vehicleName)
        );

        vehicleText.setTextSize(18);
        vehicleText.setTextColor(
                Color.parseColor("#263326")
        );

        vehicleText.setTypeface(
                null,
                Typeface.BOLD
        );

        card.addView(vehicleText);

        // Route
        TextView routeText = new TextView(this);

        routeText.setText(
                safeText(startLocation)
                        + "  →  "
                        + safeText(endLocation)
        );

        routeText.setTextSize(15);

        routeText.setTextColor(
                Color.parseColor("#4E5C4E")
        );

        routeText.setPadding(
                0,
                dpToPx(10),
                0,
                0
        );

        card.addView(routeText);

        // Distance
        TextView distanceText = new TextView(this);

        distanceText.setText(
                String.format(
                        Locale.getDefault(),
                        "%.1f km",
                        distanceKm
                )
        );

        distanceText.setTextSize(16);

        distanceText.setTypeface(
                null,
                Typeface.BOLD
        );

        distanceText.setTextColor(
                Color.parseColor("#5F9C50")
        );

        distanceText.setPadding(
                0,
                dpToPx(8),
                0,
                0
        );

        card.addView(distanceText);

        // Date
        TextView dateText = new TextView(this);

        dateText.setText(
                "Date: " + safeText(date)
        );

        dateText.setTextSize(13);

        dateText.setTextColor(
                Color.parseColor("#788278")
        );

        dateText.setPadding(
                0,
                dpToPx(5),
                0,
                0
        );

        card.addView(dateText);

        tripListContainer.addView(card);
    }

    private String safeText(String value) {

        if (value == null || value.trim().isEmpty()) {
            return "Not specified";
        }

        return value;
    }

    private int dpToPx(int dp) {

        float density =
                getResources()
                        .getDisplayMetrics()
                        .density;

        return Math.round(dp * density);
    }

    private static class TripItem {

        String vehicleName;
        String startLocation;
        String endLocation;
        String date;

        double distanceKm;
        long createdAt;

        TripItem(
                String vehicleName,
                String startLocation,
                String endLocation,
                String date,
                double distanceKm,
                long createdAt
        ) {

            this.vehicleName = vehicleName;
            this.startLocation = startLocation;
            this.endLocation = endLocation;
            this.date = date;
            this.distanceKm = distanceKm;
            this.createdAt = createdAt;
        }

        long getCreatedAt() {
            return createdAt;
        }
    }
}