
package com.firstapp.fuelwisesa;

import android.content.Context;
import android.content.SharedPreferences;

public class TrackingSessionManager {

    private static final String PREFS = "fuelwise_tracking_session";

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(
                PREFS, Context.MODE_PRIVATE);
    }

    public static void authorize(
            Context context,
            String uid,
            String vehicleId,
            String vehicleName) {

        if (uid == null || uid.isEmpty() ||
                vehicleId == null || vehicleId.isEmpty()) {
            throw new IllegalArgumentException(
                    "User and vehicle required");
        }

        prefs(context).edit()
                .putString("ownerUid", uid)
                .putString("vehicleId", vehicleId)
                .putString("vehicleName", vehicleName)
                .putBoolean("enabled", true)
                .apply();
    }

    public static boolean isEnabled(Context context) {
        return prefs(context).getBoolean("enabled", false);
    }

    public static String ownerUid(Context context) {
        return prefs(context).getString("ownerUid", null);
    }

    public static String vehicleId(Context context) {
        return prefs(context).getString("vehicleId", null);
    }

    public static String vehicleName(Context context) {
        return prefs(context).getString("vehicleName", "");
    }

    public static void disable(Context context) {
        prefs(context).edit()
                .putBoolean("enabled", false)
                .apply();
    }
}

