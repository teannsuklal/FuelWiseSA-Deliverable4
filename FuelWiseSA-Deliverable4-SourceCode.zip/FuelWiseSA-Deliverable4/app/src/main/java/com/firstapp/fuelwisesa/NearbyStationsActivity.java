
package com.firstapp.fuelwisesa;

import android.Manifest;
import androidx.appcompat.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.google.android.gms.tasks.CancellationTokenSource;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.text.DateFormat;
import java.util.Date;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class NearbyStationsActivity extends AppCompatActivity {
    private static final String[] OVERPASS_ENDPOINTS = {
            "https://overpass.private.coffee/api/interpreter",
            "https://overpass.nchc.org.tw/api/interpreter",
            "https://overpass-api.de/api/interpreter"
    };
    private static final String CACHE_PREFS = "fuelwise_station_cache";
    private static final long CACHE_FRESH_MS = 6L * 60 * 60 * 1000;
    private static final long CACHE_FALLBACK_MS = 7L * 24 * 60 * 60 * 1000;
    private static final int MAX_CACHE_ENTRIES = 8;
    private static final String CACHE_ENTRIES_KEY = "entries_v2";
    private Spinner fuelSpinner, radiusSpinner;
    private Button findButton;
    private TextView status;
    private LinearLayout results;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private CancellationTokenSource locationToken;
    private int searchGeneration = 0;
    private String selectedRegion = null;
    private String priceSummary = "Regional price: Not loaded";
    private final List<Station> visibleStations = new ArrayList<>();
    private int priceGeneration = 0;
    private Location lastSearchLocation;
    private int lastSearchRadius = 5000;

    private final ActivityResultLauncher<String[]> permissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), permissions -> {
                if (hasLocationPermission()) searchNearby();
                else showLastSavedStations(++searchGeneration, "Location permission not granted");
            });

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nearby_stations);
        fuelSpinner = findViewById(R.id.spinnerFuelType);
        radiusSpinner = findViewById(R.id.spinnerRadius);
        findButton = findViewById(R.id.btnFindStations);
        status = findViewById(R.id.tvStationStatus);
        results = findViewById(R.id.stationListContainer);
        findViewById(R.id.btnBackDashboard).setOnClickListener(v -> finish());

        String[] fuels = {"Petrol 93", "Petrol 95", "Diesel 50ppm", "Diesel 500ppm"};
        String[] radii = {"2 km", "5 km", "10 km", "20 km"};
        fuelSpinner.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, fuels));
        radiusSpinner.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, radii));
        findButton.setOnClickListener(v -> chooseRegionAndSearch());
        fuelSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view,
                                                 int position, long id) {
                if (selectedRegion != null) loadRegionalPrice();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { }
        });
    }

    // A selected region is required: GPS coordinates alone do not establish
    // which published pricing region applies to every South African location.
    private void chooseRegionAndSearch() {
        // AlertDialog uses its content area for the radio list; do not setMessage().
        String[] choices = {"Reef / Inland", "Coast"};
        new AlertDialog.Builder(this)
                .setTitle("Select pricing region")
                .setSingleChoiceItems(choices, "Coast".equals(selectedRegion) ? 1 : 0,
                        (dialog, which) -> {
                            selectedRegion = which == 0 ? "Reef" : "Coast";
                            dialog.dismiss();
                            loadRegionalPrice();
                            if (hasLocationPermission()) searchNearby();
                            else permissionLauncher.launch(new String[]{
                                    Manifest.permission.ACCESS_FINE_LOCATION,
                                    Manifest.permission.ACCESS_COARSE_LOCATION});
                        })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private String priceDocumentId() {
        String prefix = "Coast".equals(selectedRegion) ? "coast" : "reef";
        switch (fuelSpinner.getSelectedItemPosition()) {
            case 0: return prefix + "_petrol_93_unleaded";
            case 1: return prefix + "_petrol_95_unleaded";
            case 2: return prefix + "_diesel_50ppm";
            case 3: return prefix + "_diesel_500ppm";
            default: return null;
        }
    }

    private void loadRegionalPrice() {
        final String id = priceDocumentId();
        if (id == null || selectedRegion == null) return;
        final int generation = ++priceGeneration;
        priceSummary = "Regional price: Loading...";
        refreshVisibleCards();

        FirebaseFirestore.getInstance().collection("fuel_prices").document(id).get()
                .addOnSuccessListener(doc -> {
                    if (generation != priceGeneration || isFinishing() || isDestroyed()) return;
                    if (!doc.exists()) {
                        priceSummary = "Regional reference price unavailable";
                    } else {
                        Double amount = doc.getDouble("priceZarPerLitre");
                        String unit = doc.getString("unit");
                        String priceType = doc.getString("priceType");
                        String effective = doc.getString("effectiveDate");
                        String source = doc.getString("source");
                        String region = doc.getString("region");
                        String expectedType = fuelSpinner.getSelectedItemPosition() < 2
                                ? "regulated_retail" : "wholesale_reference";

                        // Never infer units or silently convert unverified raw values.
                        if (amount == null || !Double.isFinite(amount) || amount <= 0
                                || !"ZAR/L".equals(unit)
                                || !expectedType.equals(priceType)
                                || !selectedRegion.equals(region)) {
                            priceSummary = "Regional reference price unavailable (unverified data)";
                        } else {
                            String label = "regulated_retail".equals(priceType)
                                    ? "Regional regulated petrol retail reference"
                                    : "Regional diesel wholesale reference";
                            String dateLabel = formatEffectiveDate(effective);
                            priceSummary = label + " (" + selectedRegion + "): "
                                    + String.format(Locale.US, "R%.2f/L", amount)
                                    + "\nNot a verified price at this station"
                                    + "\nEffective: " + dateLabel
                                    + " · Source: " + (source == null ? "unknown" : source);
                        }
                    }
                    refreshVisibleCards();
                })
                .addOnFailureListener(e -> {
                    if (generation != priceGeneration || isFinishing() || isDestroyed()) return;
                    priceSummary = "Regional reference price unavailable (Firestore read failed)";
                    refreshVisibleCards();
                });
    }

    private String formatEffectiveDate(String value) {
        if (value == null || value.isEmpty()) return "unknown";
        try {
            java.time.Instant instant = java.time.Instant.parse(value);
            return new java.text.SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
                    .format(new Date(instant.toEpochMilli()));
        } catch (Exception ignored) {
            return value;
        }
    }

    private void refreshVisibleCards() {
        if (results == null) return;
        results.removeAllViews();
        for (Station station : visibleStations) addStationCard(station);
    }

    private boolean hasLocationPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                        == PackageManager.PERMISSION_GRANTED;
    }

    private void searchNearby() {
        if (!hasLocationPermission()) return;
        final int generation = ++searchGeneration;
        findButton.setEnabled(false);
        status.setText("Getting your current location...");
        visibleStations.clear();
        results.removeAllViews();
        locationToken = new CancellationTokenSource();
        try {
            LocationServices.getFusedLocationProviderClient(this)
                    .getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, locationToken.getToken())
                    .addOnSuccessListener(location -> {
                        if (generation != searchGeneration || isFinishing()) return;
                        if (location == null) {
                            showLastSavedStations(generation, "Current location unavailable");
                            return;
                        }
                        String selected = radiusSpinner.getSelectedItem().toString();
                        int radiusMetres = Integer.parseInt(selected.split(" ")[0]) * 1000;
                        lastSearchLocation = location;
                        lastSearchRadius = radiusMetres;
                        status.setText("Searching for stations...");
                        executor.execute(() -> queryStations(location, radiusMetres, generation));
                    })
                    .addOnFailureListener(e -> showLastSavedStations(generation,
                            "Location unavailable"));
        } catch (SecurityException e) {
            finishWithMessage("Location permission is missing.");
        }
    }

    private void queryStations(Location user, int radiusMetres, int generation) {
        CacheEntry cached = findCache(user, radiusMetres, CACHE_FRESH_MS);
        if (cached != null) {
            renderResponse(cached.response, user, radiusMetres, generation,
                    cacheDescription(cached, false));
            return;
        }

        String coords = String.format(Locale.US, "%.7f,%.7f",
                user.getLatitude(), user.getLongitude());
        String query = "[out:json][timeout:25];(node[\"amenity\"=\"fuel\"](around:"
                + radiusMetres + "," + coords + ");way[\"amenity\"=\"fuel\"](around:"
                + radiusMetres + "," + coords + "););out center;";
        String lastError = "No response";
        for (String endpoint : OVERPASS_ENDPOINTS) {
            if (Thread.currentThread().isInterrupted()) return;
            try {
                String response = fetchOverpass(endpoint, query);
                // Only store a response after successful JSON validation.
                saveCache(response, user, radiusMetres);
                renderResponse(response, user, radiusMetres, generation,
                        "Live OpenStreetMap data · saved now");
                return;
            } catch (Exception e) {
                lastError = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                android.util.Log.w("FuelWiseStations", "Overpass endpoint failed: " + endpoint, e);
            }
        }

        CacheEntry fallback = findCache(user, radiusMetres, CACHE_FALLBACK_MS);
        if (fallback != null) {
            renderResponse(fallback.response, user, radiusMetres, generation,
                    cacheDescription(fallback, true));
        } else {
            final String message = lastError;
            main.post(() -> {
                if (generation == searchGeneration && !isFinishing())
                    finishWithMessage("Station servers unavailable (" + message
                            + "). No saved stations for this area. Try again later.");
            });
        }
    }

    private void renderResponse(String response, Location user, int radiusMetres,
                                int generation, String source) {
        try {
            JSONArray elements = new JSONObject(response).getJSONArray("elements");
            List<Station> stations = new ArrayList<>();
            Set<String> seen = new HashSet<>();
            for (int i = 0; i < elements.length(); i++) {
                JSONObject element = elements.getJSONObject(i);
                JSONObject coords = element.optJSONObject("center");
                if (coords == null) coords = element;
                if (!coords.has("lat") || !coords.has("lon")) continue;
                String key = element.optString("type") + ":" + element.optString("id");
                if (!seen.add(key)) continue;
                double lat = coords.getDouble("lat"), lon = coords.getDouble("lon");
                float[] distances = new float[1];
                Location.distanceBetween(user.getLatitude(), user.getLongitude(), lat, lon, distances);
                if (distances[0] > radiusMetres) continue;
                JSONObject tags = element.optJSONObject("tags");
                if (tags == null) tags = new JSONObject();
                String name = tags.optString("name", tags.optString("brand", "Fuel station"));
                String street = tags.optString("addr:street", "");
                String number = tags.optString("addr:housenumber", "");
                String suburb = tags.optString("addr:suburb", "");
                String address = (number + " " + street + (suburb.isEmpty() ? "" : ", " + suburb)).trim();
                stations.add(new Station(name, tags.optString("brand", ""), address,
                        lat, lon, distances[0]));
            }
            Collections.sort(stations, Comparator.comparingDouble(st -> st.metres));
            main.post(() -> {
                if (generation != searchGeneration || isFinishing() || isDestroyed()) return;
                findButton.setEnabled(true);
                status.setText(stations.size() + " stations found · " + source
                        + ". Distances are straight-line estimates. Prices are regional references, not station-specific.");
                visibleStations.clear();
                visibleStations.addAll(stations);
                refreshVisibleCards();
            });
        } catch (Exception e) {
            main.post(() -> {
                if (generation == searchGeneration && !isFinishing())
                    finishWithMessage("Station data could not be read: " + e.getMessage());
            });
        }
    }

    private void showLastSavedStations(int generation, String reason) {
        executor.execute(() -> {
            CacheEntry entry = findNewestCache();
            if (entry == null) {
                main.post(() -> {
                    if (generation == searchGeneration && !isFinishing())
                        finishWithMessage(reason + ". No saved station results available.");
                });
                return;
            }
            Location cachedLocation = new Location("saved-station-search");
            cachedLocation.setLatitude(entry.lat);
            cachedLocation.setLongitude(entry.lon);
            renderResponse(entry.response, cachedLocation, entry.radius, generation,
                    "Offline saved search near previous location · " + cacheDescription(entry, true)
                            + " · distances from saved location, not your current position");
        });
    }

    private String fetchOverpass(String endpoint, String query) throws Exception {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(endpoint).openConnection();
            connection.setRequestMethod("POST");
            connection.setDoOutput(true);
            connection.setConnectTimeout(10000);
            connection.setReadTimeout(30000);
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            connection.setRequestProperty("User-Agent", "FuelWiseSA-Android-Prototype/1.0");
            String body = "data=" + java.net.URLEncoder.encode(query, "UTF-8");
            try (OutputStream out = connection.getOutputStream()) {
                out.write(body.getBytes(StandardCharsets.UTF_8));
            }
            int code = connection.getResponseCode();
            if (code != 200) throw new IOException("HTTP " + code);
            StringBuilder response = new StringBuilder();
            try (InputStream in = connection.getInputStream();
                 BufferedReader reader = new BufferedReader(
                         new InputStreamReader(in, StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                    if (response.length() > 4_000_000)
                        throw new IOException("Station response too large");
                }
            }
            // Validate before caching.
            new JSONObject(response.toString()).getJSONArray("elements");
            return response.toString();
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static class CacheEntry {
        final String response;
        final double lat, lon;
        final int radius;
        final long savedAt;
        CacheEntry(String response, double lat, double lon, int radius, long savedAt) {
            this.response = response;
            this.lat = lat;
            this.lon = lon;
            this.radius = radius;
            this.savedAt = savedAt;
        }
    }

    private synchronized List<CacheEntry> readCache() {
        List<CacheEntry> entries = new ArrayList<>();
        String json = getSharedPreferences(CACHE_PREFS, MODE_PRIVATE)
                .getString(CACHE_ENTRIES_KEY, "[]");
        try {
            JSONArray array = new JSONArray(json);
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.getJSONObject(i);
                long time = item.getLong("time");
                long age = System.currentTimeMillis() - time;
                if (age < 0 || age > CACHE_FALLBACK_MS) continue;
                String response = item.getString("response");
                new JSONObject(response).getJSONArray("elements");
                entries.add(new CacheEntry(response, item.getDouble("lat"),
                        item.getDouble("lon"), item.getInt("radius"), time));
            }
        } catch (Exception e) {
            android.util.Log.w("FuelWiseStations", "Saved station cache invalid", e);
        }
        // Import the previous single-entry cache when upgrading the app.
        if (entries.isEmpty()) {
            SharedPreferences old = getSharedPreferences(CACHE_PREFS, MODE_PRIVATE);
            String response = old.getString("response", null);
            long savedAt = old.getLong("time", 0);
            long age = System.currentTimeMillis() - savedAt;
            if (response != null && age >= 0 && age <= CACHE_FALLBACK_MS) {
                try {
                    new JSONObject(response).getJSONArray("elements");
                    entries.add(new CacheEntry(response,
                            Double.longBitsToDouble(old.getLong("lat", 0)),
                            Double.longBitsToDouble(old.getLong("lon", 0)),
                            old.getInt("radius", 0), savedAt));
                } catch (Exception ignored) { }
            }
        }
        return entries;
    }

    private synchronized void saveCache(String response, Location location, int radius) {
        try {
            new JSONObject(response).getJSONArray("elements");
            List<CacheEntry> entries = readCache();
            JSONArray array = new JSONArray();
            JSONObject newest = new JSONObject();
            newest.put("response", response);
            newest.put("lat", location.getLatitude());
            newest.put("lon", location.getLongitude());
            newest.put("radius", radius);
            newest.put("time", System.currentTimeMillis());
            array.put(newest);
            for (CacheEntry entry : entries) {
                if (array.length() >= MAX_CACHE_ENTRIES) break;
                float[] d = new float[1];
                Location.distanceBetween(location.getLatitude(), location.getLongitude(),
                        entry.lat, entry.lon, d);
                if (entry.radius == radius && d[0] < 250f) continue;
                JSONObject item = new JSONObject();
                item.put("response", entry.response);
                item.put("lat", entry.lat);
                item.put("lon", entry.lon);
                item.put("radius", entry.radius);
                item.put("time", entry.savedAt);
                array.put(item);
            }
            getSharedPreferences(CACHE_PREFS, MODE_PRIVATE).edit()
                    .putString(CACHE_ENTRIES_KEY, array.toString()).apply();
        } catch (Exception e) {
            android.util.Log.w("FuelWiseStations", "Could not save station cache", e);
        }
    }

    private CacheEntry findCache(Location user, int radius, long maxAge) {
        CacheEntry best = null;
        for (CacheEntry entry : readCache()) {
            if (System.currentTimeMillis() - entry.savedAt > maxAge) continue;
            // Reuse only a cached search covering the requested circle.
            float[] d = new float[1];
            Location.distanceBetween(user.getLatitude(), user.getLongitude(),
                    entry.lat, entry.lon, d);
            if (d[0] + radius > entry.radius) continue;
            if (best == null || entry.savedAt > best.savedAt) best = entry;
        }
        return best;
    }

    private CacheEntry findNewestCache() {
        CacheEntry best = null;
        for (CacheEntry entry : readCache()) {
            if (best == null || entry.savedAt > best.savedAt) best = entry;
        }
        return best;
    }

    private String cacheDescription(CacheEntry entry, boolean fallback) {
        String timestamp = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
                .format(new Date(entry.savedAt));
        return (fallback ? "Offline fallback" : "Saved nearby stations")
                + " · last retrieved " + timestamp;
    }

    private void addStationCard(Station station) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        int p = dp(16);
        card.setPadding(p, p, p, p);
        card.setBackgroundResource(R.drawable.bg_dashboard_blue);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.bottomMargin = dp(12);
        results.addView(card, params);
        TextView title = new TextView(this);
        title.setText(station.name);
        title.setTextSize(17);
        title.setTextColor(Color.rgb(38, 51, 38));
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        card.addView(title);
        TextView detail = new TextView(this);
        detail.setText((station.brand.isEmpty() ? "" : station.brand + " · ") +
                String.format(Locale.getDefault(), "%.1f km away", station.metres / 1000f) +
                (station.address.isEmpty() ? "" : "\n" + station.address) +
                "\n" + priceSummary);
        detail.setTextSize(13);
        detail.setTextColor(Color.rgb(85, 112, 110));
        detail.setPadding(0, dp(7), 0, dp(10));
        card.addView(detail);
        Button navigate = new Button(this);
        navigate.setText("Navigate");
        navigate.setAllCaps(false);
        navigate.setOnClickListener(v -> {
            Uri uri = Uri.parse("https://www.google.com/maps/dir/?api=1&destination=" +
                    String.format(Locale.US, "%.7f,%.7f", station.lat, station.lon));
            try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
            catch (ActivityNotFoundException e) {
                Toast.makeText(this, "No navigation app available", Toast.LENGTH_LONG).show();
            }
        });
        card.addView(navigate);
    }

    private void finishWithMessage(String message) {
        findButton.setEnabled(true);
        status.setText(message);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override protected void onDestroy() {
        ++searchGeneration;
        if (locationToken != null) locationToken.cancel();
        executor.shutdownNow();
        super.onDestroy();
    }

    private static class Station {
        final String name, brand, address;
        final double lat, lon;
        final float metres;
        Station(String name, String brand, String address, double lat, double lon, float metres) {
            this.name = name; this.brand = brand; this.address = address;
            this.lat = lat; this.lon = lon; this.metres = metres;
        }
    }
}

