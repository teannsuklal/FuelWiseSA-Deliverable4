
package com.firstapp.fuelwisesa;

import android.Manifest;
import android.content.Intent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.app.ActivityManager;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.Locale;

public class DashboardActivity extends AppCompatActivity {

    // Existing buttons
    private Button btnAddRefuel;
    private Button btnAddTrip;
    private Button btnNearbyStations;
    private Button btnMyVehicles;
    private Button btnTripHistory;
    private Button btnRefuelHistory;

    // Automatic detection
    private Button btnAutomaticTripDetection;
    private Button btnLogout;
    private TextView tvAutoTripStatus;

    // Dashboard information
    private TextView tvSelectedVehicle;
    private TextView tvVehicleDetails;
    private TextView tvFuelSpend;
    private TextView tvFuelLitres;
    private TextView tvDistance;
    private TextView tvRecentActivity;

    // Firebase
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    private String pendingOwnerUid;
    private String pendingVehicleId;
    private String pendingVehicleName;
    private boolean waitingForStop = false;
    private boolean logoutAfterStop = false;

    // Registered only while the Dashboard is visible.
    private final BroadcastReceiver stoppedReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!TripDetectionService.ACTION_TRACKING_STOPPED.equals(intent.getAction())) return;
            if (!waitingForStop) return;
            if (TrackingSessionManager.isEnabled(DashboardActivity.this)) {
                Toast.makeText(DashboardActivity.this,
                        "Tracking has not confirmed a safe stop", Toast.LENGTH_LONG).show();
                return;
            }
            waitingForStop = false;
            boolean logout = logoutAfterStop;
            logoutAfterStop = false;
            updateAutomaticDetectionUI();
            if (logout) finishLogout();
            else Toast.makeText(DashboardActivity.this,
                    "Tracking stopped safely", Toast.LENGTH_SHORT).show();
        }
    };

    // ---------------------------------------------------------
    // LOCATION PERMISSION
    // ---------------------------------------------------------

    private final ActivityResultLauncher<String[]> locationPermissionLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.RequestMultiplePermissions(),
                    result -> {

                        Boolean fineGranted =
                                result.get(
                                        Manifest.permission.ACCESS_FINE_LOCATION
                                );

                        Boolean coarseGranted =
                                result.get(
                                        Manifest.permission.ACCESS_COARSE_LOCATION
                                );

                        if (Boolean.TRUE.equals(fineGranted)) {

                            authorizeAndStartTracking();

                        } else if (Boolean.TRUE.equals(coarseGranted)) {

                            Toast.makeText(
                                    this,
                                    "Precise location is recommended for accurate trip tracking.",
                                    Toast.LENGTH_LONG
                            ).show();

                        } else {

                            Toast.makeText(
                                    this,
                                    "Location permission is required for automatic trip detection.",
                                    Toast.LENGTH_LONG
                            ).show();
                        }
                    }
            );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(
                R.layout.activity_dashboard
        );

        // -----------------------------------------------------
        // CONNECT EXISTING BUTTONS
        // -----------------------------------------------------

        btnAddRefuel =
                findViewById(
                        R.id.btnAddRefuel
                );

        btnAddTrip =
                findViewById(
                        R.id.btnAddTrip
                );

        btnNearbyStations =
                findViewById(
                        R.id.btnNearbyStations
                );

        btnMyVehicles =
                findViewById(
                        R.id.btnMyVehicles
                );

        btnTripHistory =
                findViewById(
                        R.id.btnTripHistory
                );

        btnRefuelHistory =
                findViewById(
                        R.id.btnRefuelHistory
                );

        // -----------------------------------------------------
        // AUTOMATIC TRIP DETECTION
        // -----------------------------------------------------

        btnAutomaticTripDetection =
                findViewById(
                        R.id.btnAutomaticTripDetection
                );

        tvAutoTripStatus =
                findViewById(
                        R.id.tvAutoTripStatus
                );

        // -----------------------------------------------------
        // DASHBOARD INFORMATION
        // -----------------------------------------------------

        tvSelectedVehicle =
                findViewById(
                        R.id.tvSelectedVehicle
                );

        tvVehicleDetails =
                findViewById(
                        R.id.tvVehicleDetails
                );

        tvFuelSpend =
                findViewById(
                        R.id.tvFuelSpend
                );

        tvFuelLitres =
                findViewById(
                        R.id.tvFuelLitres
                );

        tvDistance =
                findViewById(
                        R.id.tvDistance
                );

        tvRecentActivity =
                findViewById(
                        R.id.tvRecentActivity
                );

        // -----------------------------------------------------
        // FIREBASE
        // -----------------------------------------------------

        mAuth =
                FirebaseAuth.getInstance();

        db =
                FirebaseFirestore.getInstance();

        btnLogout = findViewById(R.id.btnLogout);
        btnLogout.setOnClickListener(v -> showLogoutDialog());
        updateAutomaticDetectionUI();

        // -----------------------------------------------------
        // ADD REFUEL
        // -----------------------------------------------------

        btnAddRefuel.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            DashboardActivity.this,
                            AddRefuelActivity.class
                    );

            startActivity(intent);
        });

        // -----------------------------------------------------
        // MANUAL ADD TRIP
        // -----------------------------------------------------

        btnAddTrip.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            DashboardActivity.this,
                            AddTripActivity.class
                    );

            startActivity(intent);
        });

        // -----------------------------------------------------
        // NEARBY STATIONS
        // -----------------------------------------------------

        btnNearbyStations.setOnClickListener(v -> {
            Intent intent = new Intent(
                    DashboardActivity.this,
                    NearbyStationsActivity.class
            );

            startActivity(intent);
        });

        // -----------------------------------------------------
        // VEHICLES
        // -----------------------------------------------------

        btnMyVehicles.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            DashboardActivity.this,
                            VehicleActivity.class
                    );

            startActivity(intent);
        });

        // -----------------------------------------------------
        // TRIP HISTORY
        // -----------------------------------------------------

        btnTripHistory.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            DashboardActivity.this,
                            TripHistoryActivity.class
                    );

            startActivity(intent);
        });

        // -----------------------------------------------------
        // REFUEL HISTORY
        // -----------------------------------------------------

        btnRefuelHistory.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            DashboardActivity.this,
                            RefuelLogActivity.class
                    );

            startActivity(intent);
        });

        btnAutomaticTripDetection.setOnClickListener(v -> {
            if (TrackingSessionManager.isEnabled(this)) {
                new AlertDialog.Builder(this)
                        .setTitle("Stop automatic detection?")
                        .setMessage("FuelWise will save an active trip locally before stopping. " +
                                "If saving fails, tracking will remain enabled.")
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Stop tracking", (d, w) -> requestSafeStop(false))
                        .show();
            } else requestAutomaticTripDetection();
        });
    }

    @Override protected void onStart() {
        super.onStart();
        ContextCompat.registerReceiver(this, stoppedReceiver,
                new IntentFilter(TripDetectionService.ACTION_TRACKING_STOPPED),
                ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    @Override protected void onStop() {
        unregisterReceiver(stoppedReceiver);
        super.onStop();
    }

    @Override protected void onResume() {
        super.onResume();
        if (mAuth.getCurrentUser() == null) {
            openLogin();
            return;
        }
        loadDashboardData();
        updateAutomaticDetectionUI();
        TripSyncManager.sync(getApplicationContext());
    }

    private void requestAutomaticTripDetection() {
        FirebaseUser user = mAuth.getCurrentUser();
        if (user == null) { openLogin(); return; }
        final String uid = user.getUid();

        // Never replace another user's existing tracking authorisation.
        String owner = TrackingSessionManager.ownerUid(this);
        if (TrackingSessionManager.isEnabled(this) && owner != null && !owner.equals(uid)) {
            Toast.makeText(this, "Tracking belongs to another account", Toast.LENGTH_LONG).show();
            return;
        }

        db.collection("vehicles").whereEqualTo("userId", uid).limit(1).get()
                .addOnSuccessListener(snapshot -> {
                    FirebaseUser current = mAuth.getCurrentUser();
                    if (current == null || !uid.equals(current.getUid())) return;
                    if (snapshot.isEmpty()) {
                        Toast.makeText(this, "Add a vehicle first", Toast.LENGTH_LONG).show();
                        return;
                    }
                    DocumentSnapshot vehicle = snapshot.getDocuments().get(0);
                    pendingOwnerUid = uid;
                    pendingVehicleId = vehicle.getId();
                    pendingVehicleName = (safeText(vehicle.getString("make")) + " " +
                            safeText(vehicle.getString("model"))).trim();
                    checkLocationPermission();
                })
                .addOnFailureListener(e -> Toast.makeText(this,
                        "Could not load vehicle: " + e.getMessage(), Toast.LENGTH_LONG).show());
    }

    private void checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            authorizeAndStartTracking();
        } else {
            locationPermissionLauncher.launch(new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
            });
        }
    }

    private void authorizeAndStartTracking() {
        FirebaseUser user = mAuth.getCurrentUser();
        if (user == null || pendingOwnerUid == null ||
                !pendingOwnerUid.equals(user.getUid()) || pendingVehicleId == null) {
            Toast.makeText(this, "Tracking authorisation expired", Toast.LENGTH_LONG).show();
            return;
        }
        TrackingSessionManager.authorize(this, pendingOwnerUid,
                pendingVehicleId, pendingVehicleName);
        try {
            ContextCompat.startForegroundService(this,
                    new Intent(this, TripDetectionService.class));
            Toast.makeText(this, "Tracking requested; check the notification",
                    Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            TrackingSessionManager.disable(this);
            Toast.makeText(this, "Could not start tracking: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
        updateAutomaticDetectionUI();
    }

    private void showLogoutDialog() {
        if (!TrackingSessionManager.isEnabled(this)) {
            new AlertDialog.Builder(this)
                    .setTitle("Log out?")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Log out", (d, w) -> finishLogout())
                    .show();
            return;
        }
        String owner = TrackingSessionManager.ownerUid(this);
        FirebaseUser user = mAuth.getCurrentUser();
        if (user == null || !user.getUid().equals(owner)) {
            Toast.makeText(this, "Tracking belongs to another account", Toast.LENGTH_LONG).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Logout and trip tracking")
                .setMessage("Continue tracking after logout? Location recording will remain active " +
                        "with a visible notification. Completed trips stay encrypted on this device " +
                        "until this account signs back in. You can stop tracking from the notification.")
                .setNegativeButton("Cancel", null)
                .setNeutralButton("Stop tracking & log out", (d, w) -> requestSafeStop(true))
                .setPositiveButton("Continue tracking & log out", (d, w) -> {
                    if (!isServiceRunning()) {
                        Toast.makeText(this, "Tracking service is not running. " +
                                "Restart tracking before choosing this option.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    finishLogout();
                }).show();
    }

    private void requestSafeStop(boolean logout) {
        if (waitingForStop) return;
        if (!TrackingSessionManager.isEnabled(this)) {
            if (logout) finishLogout();
            else updateAutomaticDetectionUI();
            return;
        }
        waitingForStop = true;
        logoutAfterStop = logout;
        Intent stopIntent = new Intent(this, TripDetectionService.class);
        stopIntent.setAction(TripDetectionService.ACTION_STOP);
        try {
            // From a visible activity, request the service to finalise its checkpoint.
            ContextCompat.startForegroundService(this, stopIntent);
            Toast.makeText(this, "Waiting for trip to save and tracking to stop...",
                    Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            waitingForStop = false;
            logoutAfterStop = false;
            Toast.makeText(this, "Stop request failed: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    private void finishLogout() {
        mAuth.signOut();
        openLogin();
    }

    private void openLogin() {
        Intent intent = new Intent(this, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    @SuppressWarnings("deprecation")
    private boolean isServiceRunning() {
        ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        if (manager == null) return false;
        for (ActivityManager.RunningServiceInfo info : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (TripDetectionService.class.getName().equals(info.service.getClassName())
                    && info.foreground) return true;
        }
        return false;
    }

    private void updateAutomaticDetectionUI() {
        boolean enabled = TrackingSessionManager.isEnabled(this);
        FirebaseUser user = mAuth.getCurrentUser();
        String owner = TrackingSessionManager.ownerUid(this);
        if (!enabled) {
            tvAutoTripStatus.setText("Off");
            btnAutomaticTripDetection.setText("Enable Automatic Detection");
        } else if (user != null && user.getUid().equals(owner)) {
            tvAutoTripStatus.setText(isServiceRunning()
                    ? "Enabled - service running (GPS not yet verified)"
                    : "Enabled - service not running; restart required");
            btnAutomaticTripDetection.setText("Disable Automatic Detection");
        } else {
            tvAutoTripStatus.setText("Tracking authorised by another account");
            btnAutomaticTripDetection.setText("Tracking unavailable");
        }
    }

    // ---------------------------------------------------------
    // LOAD DASHBOARD
    // ---------------------------------------------------------

    private void loadDashboardData() {

        FirebaseUser currentUser =
                mAuth.getCurrentUser();

        if (currentUser == null) {
            return;
        }

        String userId =
                currentUser.getUid();

        loadVehicle(userId);
        loadTripSummary(userId);
        loadRefuelSummary(userId);
    }

    // ---------------------------------------------------------
    // VEHICLE
    // ---------------------------------------------------------

    private void loadVehicle(
            String userId
    ) {

        db.collection("vehicles")
                .whereEqualTo(
                        "userId",
                        userId
                )
                .limit(1)
                .get()
                .addOnSuccessListener(
                        queryDocumentSnapshots -> {

                            if (queryDocumentSnapshots
                                    .isEmpty()) {

                                tvSelectedVehicle.setText(
                                        "No vehicle selected"
                                );

                                tvVehicleDetails.setText(
                                        "Add a vehicle to get started"
                                );

                                return;
                            }

                            DocumentSnapshot document =
                                    queryDocumentSnapshots
                                            .getDocuments()
                                            .get(0);

                            String make =
                                    document.getString(
                                            "make"
                                    );

                            String model =
                                    document.getString(
                                            "model"
                                    );

                            String registration =
                                    document.getString(
                                            "registrationNumber"
                                    );

                            String fuelType =
                                    document.getString(
                                            "fuelType"
                                    );

                            Long year =
                                    document.getLong(
                                            "year"
                                    );

                            String vehicleName =
                                    safeText(make)
                                            + " "
                                            + safeText(model);

                            tvSelectedVehicle.setText(
                                    vehicleName.trim()
                            );

                            StringBuilder details =
                                    new StringBuilder();

                            if (year != null) {

                                details.append(
                                        year
                                );
                            }

                            if (registration != null
                                    && !registration
                                    .trim()
                                    .isEmpty()) {

                                if (details.length() > 0) {

                                    details.append(
                                            " • "
                                    );
                                }

                                details.append(
                                        registration
                                );
                            }

                            if (fuelType != null
                                    && !fuelType
                                    .trim()
                                    .isEmpty()) {

                                if (details.length() > 0) {

                                    details.append(
                                            " • "
                                    );
                                }

                                details.append(
                                        fuelType
                                );
                            }

                            tvVehicleDetails.setText(
                                    details.toString()
                            );
                        })
                .addOnFailureListener(e -> {

                    tvSelectedVehicle.setText(
                            "Could not load vehicle"
                    );
                });
    }

    // ---------------------------------------------------------
    // TRIPS
    // ---------------------------------------------------------

    private void loadTripSummary(
            String userId
    ) {

        db.collection("trips")
                .whereEqualTo(
                        "userId",
                        userId
                )
                .get()
                .addOnSuccessListener(
                        queryDocumentSnapshots -> {

                            double totalDistance =
                                    0.0;

                            long newestTripTime =
                                    -1;

                            String newestVehicle =
                                    null;

                            String newestStart =
                                    null;

                            String newestEnd =
                                    null;

                            Double newestDistance =
                                    null;

                            for (QueryDocumentSnapshot document
                                    : queryDocumentSnapshots) {

                                Double distance =
                                        document.getDouble(
                                                "distanceKm"
                                        );

                                if (distance != null) {

                                    totalDistance +=
                                            distance;
                                }

                                Long createdAt =
                                        document.getLong(
                                                "createdAt"
                                        );

                                if (createdAt != null
                                        && createdAt
                                        > newestTripTime) {

                                    newestTripTime =
                                            createdAt;

                                    newestVehicle =
                                            document.getString(
                                                    "vehicleName"
                                            );

                                    newestStart =
                                            document.getString(
                                                    "startLocation"
                                            );

                                    newestEnd =
                                            document.getString(
                                                    "endLocation"
                                            );

                                    newestDistance =
                                            distance;
                                }
                            }

                            tvDistance.setText(
                                    String.format(
                                            Locale.getDefault(),
                                            "%.1f km",
                                            totalDistance
                                    )
                            );

                            if (queryDocumentSnapshots
                                    .isEmpty()) {

                                tvRecentActivity.setText(
                                        "No activity yet.\n"
                                                + "Add a refuel or trip to get started."
                                );

                            } else {

                                String distanceText =
                                        newestDistance == null
                                                ? "0.0"
                                                : String.format(
                                                Locale.getDefault(),
                                                "%.1f",
                                                newestDistance
                                        );

                                String activity =
                                        "Latest trip\n"
                                                + safeText(
                                                newestVehicle
                                        )
                                                + "\n"
                                                + safeText(
                                                newestStart
                                        )
                                                + " → "
                                                + safeText(
                                                newestEnd
                                        )
                                                + "\n"
                                                + distanceText
                                                + " km";

                                tvRecentActivity.setText(
                                        activity
                                );
                            }
                        })
                .addOnFailureListener(e -> {

                    tvDistance.setText(
                            "0 km"
                    );
                });
    }

    // ---------------------------------------------------------
    // REFUELS
    // ---------------------------------------------------------

    private void loadRefuelSummary(
            String userId
    ) {

        db.collection("refuels")
                .whereEqualTo(
                        "userId",
                        userId
                )
                .get()
                .addOnSuccessListener(
                        queryDocumentSnapshots -> {

                            double totalLitres =
                                    0.0;

                            double totalSpend =
                                    0.0;

                            for (QueryDocumentSnapshot document
                                    : queryDocumentSnapshots) {

                                Double litres =
                                        document.getDouble(
                                                "litres"
                                        );

                                Double totalCost =
                                        document.getDouble(
                                                "totalCost"
                                        );

                                if (litres != null) {

                                    totalLitres +=
                                            litres;
                                }

                                if (totalCost != null) {

                                    totalSpend +=
                                            totalCost;
                                }
                            }

                            tvFuelLitres.setText(
                                    String.format(
                                            Locale.getDefault(),
                                            "%.1f L",
                                            totalLitres
                                    )
                            );

                            tvFuelSpend.setText(
                                    String.format(
                                            Locale.getDefault(),
                                            "R %.2f",
                                            totalSpend
                                    )
                            );
                        })
                .addOnFailureListener(e -> {

                    tvFuelLitres.setText(
                            "0.0 L"
                    );

                    tvFuelSpend.setText(
                            "R 0.00"
                    );
                });
    }

    // ---------------------------------------------------------
    // HELPER
    // ---------------------------------------------------------

    private String safeText(
            String value
    ) {

        if (value == null
                || value.trim().isEmpty()) {

            return "Unknown";
        }

        return value;
    }
}
