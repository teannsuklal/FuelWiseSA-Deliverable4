package com.firstapp.fuelwisesa;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class AddRefuelActivity extends AppCompatActivity {

    private Spinner spinnerRefuelVehicle;

    private EditText etStationName;
    private EditText etLitres;
    private EditText etPricePerLitre;
    private EditText etOdometer;
    private EditText etRefuelDate;

    private TextView tvTotalCost;

    private Button btnSaveRefuel;
    private Button btnCancelRefuel;

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    private final List<String> vehicleNames = new ArrayList<>();
    private final List<String> vehicleIds = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_refuel);

        // Connect Java to XML
        spinnerRefuelVehicle =
                findViewById(R.id.spinnerRefuelVehicle);

        etStationName =
                findViewById(R.id.etStationName);

        etLitres =
                findViewById(R.id.etLitres);

        etPricePerLitre =
                findViewById(R.id.etPricePerLitre);

        etOdometer =
                findViewById(R.id.etOdometer);

        etRefuelDate =
                findViewById(R.id.etRefuelDate);

        tvTotalCost =
                findViewById(R.id.tvTotalCost);

        btnSaveRefuel =
                findViewById(R.id.btnSaveRefuel);

        btnCancelRefuel =
                findViewById(R.id.btnCancelRefuel);

        // Firebase
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        // Load vehicles
        loadVehicles();

        // Date picker
        etRefuelDate.setOnClickListener(v ->
                showDatePicker()
        );

        // Automatically calculate total
        TextWatcher costWatcher = new TextWatcher() {

            @Override
            public void beforeTextChanged(
                    CharSequence s,
                    int start,
                    int count,
                    int after
            ) {
            }

            @Override
            public void onTextChanged(
                    CharSequence s,
                    int start,
                    int before,
                    int count
            ) {
                calculateTotal();
            }

            @Override
            public void afterTextChanged(
                    Editable s
            ) {
            }
        };

        etLitres.addTextChangedListener(costWatcher);
        etPricePerLitre.addTextChangedListener(costWatcher);

        // Save
        btnSaveRefuel.setOnClickListener(v ->
                saveRefuel()
        );

        // Cancel
        btnCancelRefuel.setOnClickListener(v ->
                finish()
        );
    }

    private void loadVehicles() {

        FirebaseUser currentUser =
                mAuth.getCurrentUser();

        if (currentUser == null) {

            Toast.makeText(
                    this,
                    "You must be logged in",
                    Toast.LENGTH_SHORT
            ).show();

            finish();
            return;
        }

        vehicleNames.clear();
        vehicleIds.clear();

        vehicleNames.add("Select vehicle");
        vehicleIds.add("");

        db.collection("vehicles")
                .whereEqualTo(
                        "userId",
                        currentUser.getUid()
                )
                .get()
                .addOnSuccessListener(
                        queryDocumentSnapshots -> {

                            for (QueryDocumentSnapshot document
                                    : queryDocumentSnapshots) {

                                String make =
                                        document.getString("make");

                                String model =
                                        document.getString("model");

                                String registration =
                                        document.getString(
                                                "registrationNumber"
                                        );

                                String vehicleName =
                                        safeText(make)
                                                + " "
                                                + safeText(model)
                                                + " - "
                                                + safeText(registration);

                                vehicleNames.add(vehicleName);
                                vehicleIds.add(document.getId());
                            }

                            ArrayAdapter<String> adapter =
                                    new ArrayAdapter<>(
                                            AddRefuelActivity.this,
                                            android.R.layout
                                                    .simple_spinner_item,
                                            vehicleNames
                                    );

                            adapter.setDropDownViewResource(
                                    android.R.layout
                                            .simple_spinner_dropdown_item
                            );

                            spinnerRefuelVehicle
                                    .setAdapter(adapter);

                            if (queryDocumentSnapshots
                                    .isEmpty()) {

                                Toast.makeText(
                                        AddRefuelActivity.this,
                                        "Add a vehicle before recording a refuel",
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                        })
                .addOnFailureListener(e -> {

                    Toast.makeText(
                            AddRefuelActivity.this,
                            "Could not load vehicles: "
                                    + e.getMessage(),
                            Toast.LENGTH_LONG
                    ).show();
                });
    }

    private void calculateTotal() {

        String litresText =
                etLitres.getText()
                        .toString()
                        .trim();

        String priceText =
                etPricePerLitre.getText()
                        .toString()
                        .trim();

        if (litresText.isEmpty()
                || priceText.isEmpty()) {

            tvTotalCost.setText("R 0.00");
            return;
        }

        try {

            double litres =
                    Double.parseDouble(litresText);

            double price =
                    Double.parseDouble(priceText);

            double total =
                    litres * price;

            tvTotalCost.setText(
                    String.format(
                            Locale.getDefault(),
                            "R %.2f",
                            total
                    )
            );

        } catch (NumberFormatException e) {

            tvTotalCost.setText("R 0.00");
        }
    }

    private void showDatePicker() {

        Calendar calendar =
                Calendar.getInstance();

        int year =
                calendar.get(Calendar.YEAR);

        int month =
                calendar.get(Calendar.MONTH);

        int day =
                calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dialog =
                new DatePickerDialog(
                        this,
                        (view,
                         selectedYear,
                         selectedMonth,
                         selectedDay) -> {

                            String date =
                                    String.format(
                                            Locale.getDefault(),
                                            "%02d/%02d/%04d",
                                            selectedDay,
                                            selectedMonth + 1,
                                            selectedYear
                                    );

                            etRefuelDate.setText(date);
                        },
                        year,
                        month,
                        day
                );

        dialog.show();
    }

    private void saveRefuel() {

        FirebaseUser currentUser =
                mAuth.getCurrentUser();

        if (currentUser == null) {

            Toast.makeText(
                    this,
                    "You must be logged in",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        // Vehicle validation
        if (spinnerRefuelVehicle
                .getSelectedItemPosition() <= 0) {

            Toast.makeText(
                    this,
                    "Please select a vehicle",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        String stationName =
                etStationName.getText()
                        .toString()
                        .trim();

        String litresText =
                etLitres.getText()
                        .toString()
                        .trim();

        String priceText =
                etPricePerLitre.getText()
                        .toString()
                        .trim();

        String odometerText =
                etOdometer.getText()
                        .toString()
                        .trim();

        String date =
                etRefuelDate.getText()
                        .toString()
                        .trim();

        // Validate station
        if (stationName.isEmpty()) {

            etStationName.setError(
                    "Enter the fuel station"
            );

            etStationName.requestFocus();
            return;
        }

        // Validate litres
        if (litresText.isEmpty()) {

            etLitres.setError(
                    "Enter litres"
            );

            etLitres.requestFocus();
            return;
        }

        // Validate price
        if (priceText.isEmpty()) {

            etPricePerLitre.setError(
                    "Enter price per litre"
            );

            etPricePerLitre.requestFocus();
            return;
        }

        // Validate odometer
        if (odometerText.isEmpty()) {

            etOdometer.setError(
                    "Enter odometer reading"
            );

            etOdometer.requestFocus();
            return;
        }

        // Validate date
        if (date.isEmpty()) {

            Toast.makeText(
                    this,
                    "Please select a date",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        double litres;
        double pricePerLitre;
        double odometer;

        try {

            litres =
                    Double.parseDouble(litresText);

            pricePerLitre =
                    Double.parseDouble(priceText);

            odometer =
                    Double.parseDouble(odometerText);

        } catch (NumberFormatException e) {

            Toast.makeText(
                    this,
                    "Please enter valid numbers",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        if (litres <= 0) {

            etLitres.setError(
                    "Litres must be greater than 0"
            );

            return;
        }

        if (pricePerLitre <= 0) {

            etPricePerLitre.setError(
                    "Price must be greater than 0"
            );

            return;
        }

        if (odometer < 0) {

            etOdometer.setError(
                    "Enter a valid odometer reading"
            );

            return;
        }

        double totalCost =
                litres * pricePerLitre;

        int selectedPosition =
                spinnerRefuelVehicle
                        .getSelectedItemPosition();

        String vehicleId =
                vehicleIds.get(selectedPosition);

        String vehicleName =
                vehicleNames.get(selectedPosition);

        String refuelId =
                db.collection("refuels")
                        .document()
                        .getId();

        Map<String, Object> refuel =
                new HashMap<>();

        refuel.put(
                "refuelId",
                refuelId
        );

        refuel.put(
                "userId",
                currentUser.getUid()
        );

        refuel.put(
                "vehicleId",
                vehicleId
        );

        refuel.put(
                "vehicleName",
                vehicleName
        );

        refuel.put(
                "stationName",
                stationName
        );

        refuel.put(
                "litres",
                litres
        );

        refuel.put(
                "pricePerLitre",
                pricePerLitre
        );

        refuel.put(
                "totalCost",
                totalCost
        );

        refuel.put(
                "odometer",
                odometer
        );

        refuel.put(
                "date",
                date
        );

        refuel.put(
                "createdAt",
                System.currentTimeMillis()
        );

        btnSaveRefuel.setEnabled(false);
        btnSaveRefuel.setText("Saving...");

        db.collection("refuels")
                .document(refuelId)
                .set(refuel)
                .addOnSuccessListener(unused -> {

                    Toast.makeText(
                            AddRefuelActivity.this,
                            "Refuel saved successfully",
                            Toast.LENGTH_SHORT
                    ).show();

                    finish();
                })
                .addOnFailureListener(e -> {

                    btnSaveRefuel.setEnabled(true);
                    btnSaveRefuel.setText(
                            "Save Refuel"
                    );

                    Toast.makeText(
                            AddRefuelActivity.this,
                            "Could not save refuel: "
                                    + e.getMessage(),
                            Toast.LENGTH_LONG
                    ).show();
                });
    }

    private String safeText(String value) {

        if (value == null
                || value.trim().isEmpty()) {

            return "Unknown";
        }

        return value;
    }
}