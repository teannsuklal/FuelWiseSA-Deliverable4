
package com.firstapp.fuelwisesa;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.AtomicFile;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class LocalTripStore {

    private static final String KEY_ALIAS = "FuelWiseTripKeyV1";
    private final AtomicFile file;

    public LocalTripStore(Context context) {
        file = new AtomicFile(
                new File(context.getFilesDir(), "pending_trips.enc")
        );
    }

    private SecretKey getKey() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);

        if (store.containsAlias(KEY_ALIAS)) {
            return ((KeyStore.SecretKeyEntry)
                    store.getEntry(KEY_ALIAS, null)).getSecretKey();
        }

        KeyGenerator generator = KeyGenerator.getInstance(
                KeyProperties.KEY_ALGORITHM_AES,
                "AndroidKeyStore"
        );

        generator.init(new KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT |
                        KeyProperties.PURPOSE_DECRYPT
        )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(
                        KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build());

        return generator.generateKey();
    }

    private synchronized JSONArray readAll() throws Exception {
        if (!file.getBaseFile().exists()) {
            return new JSONArray();
        }

        byte[] encrypted;
        try (FileInputStream input = file.openRead()) {
            encrypted = new byte[(int) file.getBaseFile().length()];
            int offset = 0;
            while (offset < encrypted.length) {
                int count = input.read(
                        encrypted, offset, encrypted.length - offset);
                if (count < 0) {
                    throw new Exception("Incomplete encrypted file");
                }
                offset += count;
            }
        }

        if (encrypted.length < 13) {
            throw new Exception("Invalid encrypted trip file");
        }

        byte[] iv = new byte[12];
        System.arraycopy(encrypted, 0, iv, 0, 12);

        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(
                Cipher.DECRYPT_MODE,
                getKey(),
                new GCMParameterSpec(128, iv)
        );

        byte[] plain = cipher.doFinal(
                encrypted, 12, encrypted.length - 12);

        return new JSONArray(
                new String(plain, StandardCharsets.UTF_8)
        );
    }

    private synchronized void writeAll(JSONArray trips)
            throws Exception {

        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, getKey());

        byte[] iv = cipher.getIV();
        byte[] data = cipher.doFinal(
                trips.toString().getBytes(StandardCharsets.UTF_8)
        );

        byte[] output = new byte[iv.length + data.length];
        System.arraycopy(iv, 0, output, 0, iv.length);
        System.arraycopy(data, 0, output, iv.length, data.length);

        FileOutputStream stream = file.startWrite();

        try {
            stream.write(output);
            file.finishWrite(stream);
        } catch (Exception e) {
            file.failWrite(stream);
            throw e;
        }
    }

    public synchronized void save(JSONObject trip) throws Exception {
        if (!trip.has("tripId") ||
                !trip.has("userId") ||
                !trip.has("vehicleId")) {
            throw new IllegalArgumentException(
                    "Trip identity fields are required");
        }

        JSONArray trips = readAll();

        for (int i = 0; i < trips.length(); i++) {
            if (trip.getString("tripId").equals(
                    trips.getJSONObject(i).getString("tripId"))) {
                return;
            }
        }

        trips.put(trip);
        writeAll(trips);
    }

    public synchronized List<JSONObject> getForUser(String uid)
            throws Exception {

        List<JSONObject> result = new ArrayList<>();
        JSONArray trips = readAll();

        for (int i = 0; i < trips.length(); i++) {
            JSONObject trip = trips.getJSONObject(i);
            if (uid.equals(trip.optString("userId"))) {
                result.add(trip);
            }
        }

        return result;
    }

    public synchronized void remove(String tripId) throws Exception {
        JSONArray oldTrips = readAll();
        JSONArray remaining = new JSONArray();

        for (int i = 0; i < oldTrips.length(); i++) {
            JSONObject trip = oldTrips.getJSONObject(i);

            if (!tripId.equals(trip.optString("tripId"))) {
                remaining.put(trip);
            }
        }

        writeAll(remaining);
    }
}

