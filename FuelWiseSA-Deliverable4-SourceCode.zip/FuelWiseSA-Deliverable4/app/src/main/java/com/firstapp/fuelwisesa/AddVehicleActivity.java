package com.firstapp.fuelwisesa;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class AddVehicleActivity extends AppCompatActivity {

    private TextView tvVehicleFormTitle;
    private TextView tvVehicleFormSubtitle;

    private EditText etVehicleMake;
    private EditText etVehicleModel;
    private EditText etRegistrationNumber;
    private EditText etVehicleYear;

    private Spinner spinnerFuelType;

    private Button btnSaveVehicle;
    private Button btnCancelVehicle;

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    // Determines whether this screen is adding or editing
    private boolean editMode = false;

    // Existing Firestore vehicle document ID
    private String vehicleId = null;

    private String[] fuelTypes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_vehicle);

        // -----------------------------------------------------
        // CONNECT XML
        // -----------------------------------------------------

        tvVehicleFormTitle =
                findViewById(R.id.tvVehicleFormTitle);

        tvVehicleFormSubtitle =
                findViewById(R.id.tvVehicleFormSubtitle);

        etVehicleMake =
                findViewById(R.id.etVehicleMake);

        etVehicleModel =
                findViewById(R.id.etVehicleModel);

        etRegistrationNumber =
                findViewById(R.id.etRegistrationNumber);

        etVehicleYear =
                findViewById(R.id.etVehicleYear);

        spinnerFuelType =
                findViewById(R.id.spinnerFuelType);

        btnSaveVehicle =
                findViewById(R.id.btnSaveVehicle);

        btnCancelVehicle =
                findViewById(R.id.btnCancelVehicle);

        // -----------------------------------------------------
        // FIREBASE
        // -----------------------------------------------------

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        // -----------------------------------------------------
        // FUEL TYPES
        // -----------------------------------------------------

        setupFuelTypeSpinner();

        // -----------------------------------------------------
        // CHECK IF EDITING
        // -----------------------------------------------------

        editMode =
                getIntent().getBooleanExtra(
                        "EDIT_MODE",
                        false
                );

        if (editMode) {
            setupEditMode();
        }

        // -----------------------------------------------------
        // BUTTONS
        // -----------------------------------------------------

        btnSaveVehicle.setOnClickListener(v ->
                saveVehicle()
        );

        btnCancelVehicle.setOnClickListener(v ->
                finish()
        );
    }

    // ---------------------------------------------------------
    // FUEL TYPE SPINNER
    // ---------------------------------------------------------

    private void setupFuelTypeSpinner() {

        fuelTypes = new String[]{
                "Select fuel type",
                "Petrol 93",
                "Petrol 95",
                "Diesel",
                "Other"
        };

        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        fuelTypes
                );

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spinnerFuelType.setAdapter(adapter);
    }

    // ---------------------------------------------------------
    // EDIT MODE
    // ---------------------------------------------------------

    private void setupEditMode() {

        vehicleId =
                getIntent().getStringExtra(
                        "VEHICLE_ID"
                );

        String make =
                getIntent().getStringExtra(
                        "MAKE"
                );

        String model =
                getIntent().getStringExtra(
                        "MODEL"
                );

        String registration =
                getIntent().getStringExtra(
                        "REGISTRATION"
                );

        long year =
                getIntent().getLongExtra(
                        "YEAR",
                        0
                );

        String fuelType =
                getIntent().getStringExtra(
                        "FUEL_TYPE"
                );

        // Change screen title
        tvVehicleFormTitle.setText(
                "Edit Vehicle"
        );

        tvVehicleFormSubtitle.setText(
                "Update your vehicle information."
        );

        btnSaveVehicle.setText(
                "Update Vehicle"
        );

        // Fill existing details
        etVehicleMake.setText(
                make == null ? "" : make
        );

        etVehicleModel.setText(
                model == null ? "" : model
        );

        etRegistrationNumber.setText(
                registration == null
                        ? ""
                        : registration
        );

        if (year > 0) {

            etVehicleYear.setText(
                    String.valueOf(year)
            );
        }

        // Select existing fuel type
        if (fuelType != null) {

            for (int i = 0;
                 i < fuelTypes.length;
                 i++) {

                if (fuelTypes[i]
                        .equalsIgnoreCase(
                                fuelType
                        )) {

                    spinnerFuelType
                            .setSelection(i);

                    break;
                }
            }
        }
    }

    // ---------------------------------------------------------
    // SAVE / UPDATE VEHICLE
    // ---------------------------------------------------------

    private void saveVehicle() {

        String make =
                etVehicleMake
                        .getText()
                        .toString()
                        .trim();

        String model =
                etVehicleModel
                        .getText()
                        .toString()
                        .trim();

        String registrationNumber =
                etRegistrationNumber
                        .getText()
                        .toString()
                        .trim()
                        .toUpperCase();

        String yearText =
                etVehicleYear
                        .getText()
                        .toString()
                        .trim();

        String fuelType =
                spinnerFuelType
                        .getSelectedItem()
                        .toString();

        // -----------------------------------------------------
        // VALIDATION
        // -----------------------------------------------------

        if (make.isEmpty()) {

            etVehicleMake.setError(
                    "Enter the vehicle make"
            );

            etVehicleMake.requestFocus();
            return;
        }

        if (model.isEmpty()) {

            etVehicleModel.setError(
                    "Enter the vehicle model"
            );

            etVehicleModel.requestFocus();
            return;
        }

        if (registrationNumber.isEmpty()) {

            etRegistrationNumber.setError(
                    "Enter the registration number"
            );

            etRegistrationNumber.requestFocus();
            return;
        }

        if (yearText.isEmpty()) {

            etVehicleYear.setError(
                    "Enter the vehicle year"
            );

            etVehicleYear.requestFocus();
            return;
        }

        if (yearText.length() != 4) {

            etVehicleYear.setError(
                    "Enter a valid 4-digit year"
            );

            etVehicleYear.requestFocus();
            return;
        }

        int year;

        try {

            year =
                    Integer.parseInt(
                            yearText
                    );

        } catch (NumberFormatException e) {

            etVehicleYear.setError(
                    "Enter a valid year"
            );

            etVehicleYear.requestFocus();
            return;
        }

        int currentYear =
                java.util.Calendar
                        .getInstance()
                        .get(
                                java.util.Calendar.YEAR
                        );

        if (year < 1886
                || year > currentYear + 1) {

            etVehicleYear.setError(
                    "Enter a valid vehicle year"
            );

            etVehicleYear.requestFocus();
            return;
        }

        if (spinnerFuelType
                .getSelectedItemPosition() == 0) {

            Toast.makeText(
                    this,
                    "Please select a fuel type",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        FirebaseUser currentUser =
                mAuth.getCurrentUser();

        if (currentUser == null) {

            Toast.makeText(
                    this,
                    "You must be logged in",
                    Toast.LENGTH_LONG
            ).show();

            return;
        }

        String userId =
                currentUser.getUid();

        // -----------------------------------------------------
        // BUILD VEHICLE DATA
        // -----------------------------------------------------

        Map<String, Object> vehicle =
                new HashMap<>();

        vehicle.put(
                "userId",
                userId
        );

        vehicle.put(
                "make",
                make
        );

        vehicle.put(
                "model",
                model
        );

        vehicle.put(
                "registrationNumber",
                registrationNumber
        );

        vehicle.put(
                "year",
                year
        );

        vehicle.put(
                "fuelType",
                fuelType
        );

        // -----------------------------------------------------
        // EDIT EXISTING VEHICLE
        // -----------------------------------------------------

        if (editMode) {

            if (vehicleId == null
                    || vehicleId.trim().isEmpty()) {

                Toast.makeText(
                        this,
                        "Could not identify this vehicle",
                        Toast.LENGTH_LONG
                ).show();

                return;
            }

            vehicle.put(
                    "vehicleId",
                    vehicleId
            );

            updateVehicle(vehicle);

        } else {

            // -------------------------------------------------
            // ADD NEW VEHICLE
            // -------------------------------------------------

            vehicleId =
                    db.collection("vehicles")
                            .document()
                            .getId();

            vehicle.put(
                    "vehicleId",
                    vehicleId
            );

            createVehicle(vehicle);
        }
    }

    // ---------------------------------------------------------
    // CREATE NEW VEHICLE
    // ---------------------------------------------------------

    private void createVehicle(
            Map<String, Object> vehicle
    ) {

        btnSaveVehicle.setEnabled(false);

        btnSaveVehicle.setText(
                "Saving..."
        );

        db.collection("vehicles")
                .document(vehicleId)
                .set(vehicle)
                .addOnSuccessListener(unused -> {

                    Toast.makeText(
                            AddVehicleActivity.this,
                            "Vehicle saved successfully",
                            Toast.LENGTH_SHORT
                    ).show();

                    finish();
                })
                .addOnFailureListener(e -> {

                    btnSaveVehicle.setEnabled(true);

                    btnSaveVehicle.setText(
                            "Save Vehicle"
                    );

                    Toast.makeText(
                            AddVehicleActivity.this,
                            "Could not save vehicle: "
                                    + e.getMessage(),
                            Toast.LENGTH_LONG
                    ).show();
                });
    }

    // ---------------------------------------------------------
    // UPDATE EXISTING VEHICLE
    // ---------------------------------------------------------

    private void updateVehicle(
            Map<String, Object> vehicle
    ) {

        btnSaveVehicle.setEnabled(false);

        btnSaveVehicle.setText(
                "Updating..."
        );

        db.collection("vehicles")
                .document(vehicleId)
                .set(vehicle)
                .addOnSuccessListener(unused -> {

                    Toast.makeText(
                            AddVehicleActivity.this,
                            "Vehicle updated successfully",
                            Toast.LENGTH_SHORT
                    ).show();

                    finish();
                })
                .addOnFailureListener(e -> {

                    btnSaveVehicle.setEnabled(true);

                    btnSaveVehicle.setText(
                            "Update Vehicle"
                    );

                    Toast.makeText(
                            AddVehicleActivity.this,
                            "Could not update vehicle: "
                                    + e.getMessage(),
                            Toast.LENGTH_LONG
                    ).show();
                });
    }
}