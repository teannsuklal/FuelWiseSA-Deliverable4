
package com.firstapp.fuelwisesa;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.AtomicFile;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class ActiveTripStore {

    private static final String KEY_ALIAS =
            "FuelWiseActiveTripKeyV1";

    private final AtomicFile file;

    public ActiveTripStore(Context context) {
        file = new AtomicFile(
                new File(
                        context.getFilesDir(),
                        "active_trip.enc"
                )
        );
    }

    private SecretKey getKey() throws Exception {

        KeyStore keyStore =
                KeyStore.getInstance("AndroidKeyStore");

        keyStore.load(null);

        if (keyStore.containsAlias(KEY_ALIAS)) {

            return ((KeyStore.SecretKeyEntry)
                    keyStore.getEntry(
                            KEY_ALIAS,
                            null
                    )).getSecretKey();
        }

        KeyGenerator generator =
                KeyGenerator.getInstance(
                        KeyProperties.KEY_ALGORITHM_AES,
                        "AndroidKeyStore"
                );

        generator.init(
                new KeyGenParameterSpec.Builder(
                        KEY_ALIAS,
                        KeyProperties.PURPOSE_ENCRYPT |
                                KeyProperties.PURPOSE_DECRYPT
                )
                        .setBlockModes(
                                KeyProperties.BLOCK_MODE_GCM
                        )
                        .setEncryptionPaddings(
                                KeyProperties.ENCRYPTION_PADDING_NONE
                        )
                        .setKeySize(256)
                        .build()
        );

        return generator.generateKey();
    }

    public synchronized void save(JSONObject trip)
            throws Exception {

        if (trip == null ||
                !trip.has("userId") ||
                !trip.has("vehicleId") ||
                !trip.has("tripId")) {

            throw new IllegalArgumentException(
                    "Active trip identity fields are required"
            );
        }

        Cipher cipher =
                Cipher.getInstance("AES/GCM/NoPadding");

        cipher.init(
                Cipher.ENCRYPT_MODE,
                getKey()
        );

        byte[] iv = cipher.getIV();

        byte[] encrypted =
                cipher.doFinal(
                        trip.toString().getBytes(
                                StandardCharsets.UTF_8
                        )
                );

        byte[] output =
                new byte[iv.length + encrypted.length];

        System.arraycopy(
                iv,
                0,
                output,
                0,
                iv.length
        );

        System.arraycopy(
                encrypted,
                0,
                output,
                iv.length,
                encrypted.length
        );

        FileOutputStream stream =
                file.startWrite();

        try {

            stream.write(output);

            file.finishWrite(stream);

        } catch (Exception e) {

            file.failWrite(stream);
            throw e;
        }
    }

    public synchronized JSONObject load()
            throws Exception {

        if (!file.getBaseFile().exists()) {
            return null;
        }

        byte[] encrypted;

        try (FileInputStream input = file.openRead()) {

            encrypted = new byte[
                    (int) file.getBaseFile().length()
                    ];

            int offset = 0;

            while (offset < encrypted.length) {

                int count = input.read(
                        encrypted,
                        offset,
                        encrypted.length - offset
                );

                if (count < 0) {
                    throw new Exception(
                            "Incomplete active trip checkpoint"
                    );
                }

                offset += count;
            }
        }

        if (encrypted.length < 13) {

            throw new Exception(
                    "Invalid active trip checkpoint"
            );
        }

        byte[] iv = new byte[12];

        System.arraycopy(
                encrypted,
                0,
                iv,
                0,
                iv.length
        );

        Cipher cipher =
                Cipher.getInstance("AES/GCM/NoPadding");

        cipher.init(
                Cipher.DECRYPT_MODE,
                getKey(),
                new GCMParameterSpec(
                        128,
                        iv
                )
        );

        byte[] plain =
                cipher.doFinal(
                        encrypted,
                        iv.length,
                        encrypted.length - iv.length
                );

        return new JSONObject(
                new String(
                        plain,
                        StandardCharsets.UTF_8
                )
        );
    }

    public synchronized boolean exists() {

        return file.getBaseFile().exists();
    }

    public synchronized void clear() {

        file.delete();
    }
}
