package com.firstapp.fuelwisesa;

import android.Manifest;
import android.app.*;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.os.*;
import android.util.Log;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.ServiceCompat;
import com.google.android.gms.location.*;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.*;

public class TripDetectionService extends Service {
    private static final String TAG = "FuelWiseTrip";
    private static final String CHANNEL = "fuelwise_trip_detection";
    private static final int NOTIFICATION_ID = 1001;
    public static final String ACTION_STOP = "com.firstapp.fuelwisesa.STOP_TRACKING";
    // Emulator-only thresholds; increase to 30000 and 120000 for road testing.
    public static final String ACTION_TRACKING_STOPPED =
            "com.firstapp.fuelwisesa.TRACKING_STOPPED";
    private static final long START_MS = 10000L, STOP_MS = 20000L;
    private static final float START_MPS = 4.2f, STOP_MPS = 1.1f;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private FusedLocationProviderClient fused;
    private LocationCallback callback;
    private ActiveTripStore store;
    private String uid, vehicleId, vehicleName, tripId;
    private boolean active, saving, stopping;
    private long startedAt, movingSince, stoppedSince, lastFixTime;
    private double metres;
    private Location previous, start, end;

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            long now = SystemClock.elapsedRealtime();
            if (active && !saving && !stopping) {
                if (stoppedSince > 0 && now - stoppedSince >= STOP_MS) finish(false);
                else if (lastFixTime > 0 && now - lastFixTime > 30000)
                    notifyStatus("Trip active - waiting for GPS");
            }
            handler.postDelayed(this, 5000);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        store = new ActiveTripStore(this);
        fused = LocationServices.getFusedLocationProviderClient(this);
        createChannel();
        startForegroundNow();
        callback = new LocationCallback() {
            @Override public void onLocationResult(LocationResult result) {
                if (result != null) for (Location loc : result.getLocations()) onFix(loc);
            }
        };
        initialize();
        handler.postDelayed(ticker, 5000);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            safeStop();
            return START_NOT_STICKY;
        }
        return TrackingSessionManager.isEnabled(this) ? START_STICKY : START_NOT_STICKY;
    }

    private void initialize() {
        if (!TrackingSessionManager.isEnabled(this)) { stopSelf(); return; }
        uid = TrackingSessionManager.ownerUid(this);
        vehicleId = TrackingSessionManager.vehicleId(this);
        vehicleName = TrackingSessionManager.vehicleName(this);
        if (uid == null || uid.isEmpty() || vehicleId == null || vehicleId.isEmpty()) {
            Log.e(TAG, "Missing authorised owner or vehicle"); stopSelf(); return;
        }
        try {
            JSONObject checkpoint = store.load();
            if (checkpoint != null) {
                if (!uid.equals(checkpoint.optString("userId")) ||
                        !vehicleId.equals(checkpoint.optString("vehicleId"))) {
                    Log.e(TAG, "Checkpoint account mismatch; not overwriting");
                    stopSelf(); return;
                }
                tripId = checkpoint.getString("tripId");
                startedAt = checkpoint.getLong("startTime");
                metres = checkpoint.optDouble("distanceMetres", 0);
                start = restoreLocation(checkpoint, "startLatitude", "startLongitude");
                end = restoreLocation(checkpoint, "endLatitude", "endLongitude");
                previous = null; // Never count distance across unknown downtime.
                active = true;
                Log.i(TAG, "Restored active trip");
            }
        } catch (Exception e) {
            Log.e(TAG, "Checkpoint recovery failed; retained for inspection", e);
            stopSelf(); return;
        }
        startGps();
    }

    private Location restoreLocation(JSONObject j, String lat, String lon) {
        if (!j.has(lat) || !j.has(lon)) return null;
        Location l = new Location("checkpoint");
        l.setLatitude(j.optDouble(lat)); l.setLongitude(j.optDouble(lon));
        return l;
    }

    private void startGps() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            Log.e(TAG, "Precise location permission missing"); stopSelf(); return;
        }
        LocationRequest request = new LocationRequest.Builder(
                Priority.PRIORITY_HIGH_ACCURACY, 5000L)
                .setMinUpdateIntervalMillis(3000L)
                .setMinUpdateDistanceMeters(0f).build();
        try {
            fused.requestLocationUpdates(request, callback, getMainLooper())
                    .addOnSuccessListener(v -> notifyStatus(
                            active ? "Recovered trip - monitoring" : "Watching for driving"))
                    .addOnFailureListener(e -> {
                        Log.e(TAG, "Location updates failed", e); stopSelf();
                    });
        } catch (SecurityException e) {
            Log.e(TAG, "Location permission denied", e); stopSelf();
        }
    }

    private void onFix(Location loc) {
        if (loc == null || stopping || saving || !TrackingSessionManager.isEnabled(this)) return;
        if (!loc.hasAccuracy() || loc.getAccuracy() > 50f) return;
        if (previous != null && previous.getElapsedRealtimeNanos() > 0 &&
                loc.getElapsedRealtimeNanos() <= previous.getElapsedRealtimeNanos()) return;
        long now = SystemClock.elapsedRealtime();
        lastFixTime = now;
        float speed = loc.hasSpeed() ? loc.getSpeed() : 0f;
        Log.d(TAG, "GPS speed=" + speed + " active=" + active);
        if (!active) {
            if (loc.hasSpeed() && speed >= START_MPS) {
                if (movingSince == 0) movingSince = now;
                notifyStatus("Movement detected");
                if (now - movingSince >= START_MS) begin(loc);
            } else movingSince = 0;
            previous = new Location(loc);
            return;
        }
        if (previous != null && previous.getElapsedRealtimeNanos() > 0) {
            long dt = (loc.getElapsedRealtimeNanos() - previous.getElapsedRealtimeNanos()) / 1000000L;
            float delta = previous.distanceTo(loc);
            if (dt > 0 && dt <= 30000 && delta >= 0 && delta / (dt / 1000f) <= 55f)
                metres += delta;
        }
        previous = new Location(loc);
        end = new Location(loc);
        if (loc.hasSpeed() && speed <= STOP_MPS) {
            if (stoppedSince == 0) stoppedSince = now;
            notifyStatus("Trip active - stopped");
        } else {
            stoppedSince = 0;
            notifyStatus(loc.hasSpeed() ? "Trip in progress" : "Trip active - speed unknown");
        }
        checkpoint();
    }

    private void begin(Location loc) {
        tripId = UUID.randomUUID().toString();
        startedAt = System.currentTimeMillis();
        metres = 0;
        active = true;
        movingSince = stoppedSince = 0;
        start = new Location(loc); end = new Location(loc); previous = new Location(loc);
        if (!checkpoint()) {
            active = false;
            notifyStatus("Storage unavailable - tracking stopped");
            safeStop(); return;
        }
        Log.i(TAG, "Trip started");
        notifyStatus("Trip in progress");
    }

    private boolean checkpoint() {
        if (!active || tripId == null) return false;
        try {
            JSONObject j = new JSONObject();
            j.put("tripId", tripId); j.put("userId", uid);
            j.put("vehicleId", vehicleId); j.put("vehicleName", vehicleName);
            j.put("startTime", startedAt); j.put("distanceMetres", metres);
            if (start != null) {
                j.put("startLatitude", start.getLatitude());
                j.put("startLongitude", start.getLongitude());
            }
            if (end != null) {
                j.put("endLatitude", end.getLatitude());
                j.put("endLongitude", end.getLongitude());
            }
            store.save(j);
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Checkpoint failed", e);
            notifyStatus("Trip storage error");
            return false;
        }
    }

    private void finish(boolean interrupted) {
        if (!active || saving) return;
        saving = true;
        try {
            JSONObject trip = new JSONObject();
            long ended = System.currentTimeMillis();
            trip.put("tripId", tripId); trip.put("userId", uid);
            trip.put("vehicleId", vehicleId); trip.put("vehicleName", vehicleName);
            trip.put("startLocation", formatLocation(start));
            trip.put("endLocation", formatLocation(end));
            trip.put("distanceKm", metres / 1000.0);
            trip.put("date", new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                    .format(new Date(startedAt)));
            trip.put("startTime", startedAt); trip.put("endTime", ended);
            trip.put("createdAt", ended); trip.put("detectionType", "automatic");
            trip.put("interrupted", interrupted);
            if (start != null) {
                trip.put("startLatitude", start.getLatitude());
                trip.put("startLongitude", start.getLongitude());
            }
            if (end != null) {
                trip.put("endLatitude", end.getLatitude());
                trip.put("endLongitude", end.getLongitude());
            }
            // Save completed trip BEFORE deleting active checkpoint.
            new LocalTripStore(this).save(trip);
            store.clear();
            Log.i(TAG, "Trip saved locally " + tripId);
            FirebaseUser signedIn = FirebaseAuth.getInstance().getCurrentUser();
            if (signedIn != null && uid.equals(signedIn.getUid()))
                TripSyncManager.sync(getApplicationContext());
            resetTrip();
            if (stopping) completeStop();
            else notifyStatus("Trip saved - watching for driving");
        } catch (Exception e) {
            Log.e(TAG, "Final save failed; checkpoint retained", e);
            saving = false;
            stopping = false;
            notifyStatus("Trip save failed - retry Stop Tracking");
        }
    }

    private String formatLocation(Location l) {
        if (l == null) return "Automatic location";
        return String.format(Locale.US, "%.5f, %.5f", l.getLatitude(), l.getLongitude());
    }

    private void safeStop() {
        if (stopping) return;
        stopping = true;
        notifyStatus("Stopping tracking safely");
        if (active) finish(true); else completeStop();
    }
    private void notifyTrackingStopped() {

        Intent intent = new Intent(ACTION_TRACKING_STOPPED);

        intent.setPackage(getPackageName());

        sendBroadcast(intent);
    }
    private void completeStop() {

        // Only called after any active trip has been
        // successfully saved, or when no trip is active.

        TrackingSessionManager.disable(this);

        if (fused != null && callback != null) {
            fused.removeLocationUpdates(callback);
        }

        notifyTrackingStopped();

        stopSelf();
    }

    private void resetTrip() {
        active = saving = false;
        tripId = null; startedAt = movingSince = stoppedSince = 0;
        metres = 0; start = end = previous = null;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel c = new NotificationChannel(CHANNEL,
                    "FuelWise Automatic Trip Detection", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Visible notification while tracking driving activity");
            NotificationManager m = getSystemService(NotificationManager.class);
            if (m != null) m.createNotificationChannel(c);
        }
    }

    private Notification makeNotification(String message) {
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, LoginActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stopIntent = new Intent(this, TripDetectionService.class);
        stopIntent.setAction(ACTION_STOP);
        PendingIntent stop = PendingIntent.getService(this, 1, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Builder(this, CHANNEL)
                .setContentTitle("FuelWise trip detection")
                .setContentText(message)
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setContentIntent(open)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop Tracking", stop)
                .setOngoing(true).setOnlyAlertOnce(true)
                .setPriority(NotificationCompat.PRIORITY_LOW).build();
    }

    private void startForegroundNow() {
        Notification n = makeNotification("Preparing trip detection");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
            ServiceCompat.startForeground(this, NOTIFICATION_ID, n,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
        else startForeground(NOTIFICATION_ID, n);
    }

    private void notifyStatus(String status) {
        NotificationManager m = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (m != null) m.notify(NOTIFICATION_ID, makeNotification(status));
    }

    @Override public void onDestroy() {
        handler.removeCallbacks(ticker);
        if (fused != null && callback != null) fused.removeLocationUpdates(callback);
        super.onDestroy();
    }

    @Nullable @Override public IBinder onBind(Intent intent) { return null; }
}


