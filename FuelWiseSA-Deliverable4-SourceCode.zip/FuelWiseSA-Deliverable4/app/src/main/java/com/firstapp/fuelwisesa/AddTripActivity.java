package com.firstapp.fuelwisesa;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class AddTripActivity extends AppCompatActivity {

    private Spinner spinnerTripVehicle;

    private EditText etStartLocation;
    private EditText etEndLocation;
    private EditText etDistance;
    private EditText etTripDate;

    private TextView tvTripDistance;

    private Button btnSaveTrip;
    private Button btnCancelTrip;

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    // Vehicle names shown to the user
    private final List<String> vehicleNames = new ArrayList<>();

    // Matching Firestore vehicle IDs
    private final List<String> vehicleIds = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_trip);

        // Connect Java to XML
        spinnerTripVehicle = findViewById(R.id.spinnerTripVehicle);

        etStartLocation = findViewById(R.id.etStartLocation);
        etEndLocation = findViewById(R.id.etEndLocation);
        etDistance = findViewById(R.id.etDistance);
        etTripDate = findViewById(R.id.etTripDate);

        tvTripDistance = findViewById(R.id.tvTripDistance);

        btnSaveTrip = findViewById(R.id.btnSaveTrip);
        btnCancelTrip = findViewById(R.id.btnCancelTrip);

        // Firebase
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        // Load user's vehicles
        loadVehicles();

        // Date picker
        etTripDate.setFocusable(false);
        etTripDate.setClickable(true);

        etTripDate.setOnClickListener(v -> showDatePicker());

        // Update distance display
        etDistance.setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus) {
                updateDistanceDisplay();
            }
        });

        // Save trip
        btnSaveTrip.setOnClickListener(v -> saveTrip());

        // Cancel
        btnCancelTrip.setOnClickListener(v -> finish());
    }

    private void loadVehicles() {

        FirebaseUser currentUser = mAuth.getCurrentUser();

        if (currentUser == null) {
            Toast.makeText(
                    this,
                    "You must be logged in",
                    Toast.LENGTH_SHORT
            ).show();

            finish();
            return;
        }

        vehicleNames.clear();
        vehicleIds.clear();

        vehicleNames.add("Select vehicle");
        vehicleIds.add("");

        db.collection("vehicles")
                .whereEqualTo("userId", currentUser.getUid())
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {

                    for (QueryDocumentSnapshot document
                            : queryDocumentSnapshots) {

                        String make = document.getString("make");
                        String model = document.getString("model");
                        String registration =
                                document.getString("registrationNumber");

                        String vehicleName =
                                safeText(make) + " " +
                                        safeText(model) +
                                        " - " +
                                        safeText(registration);

                        vehicleNames.add(vehicleName);
                        vehicleIds.add(document.getId());
                    }

                    ArrayAdapter<String> adapter =
                            new ArrayAdapter<>(
                                    AddTripActivity.this,
                                    android.R.layout.simple_spinner_item,
                                    vehicleNames
                            );

                    adapter.setDropDownViewResource(
                            android.R.layout.simple_spinner_dropdown_item
                    );

                    spinnerTripVehicle.setAdapter(adapter);

                    if (queryDocumentSnapshots.isEmpty()) {
                        Toast.makeText(
                                AddTripActivity.this,
                                "Add a vehicle before recording a trip",
                                Toast.LENGTH_LONG
                        ).show();
                    }
                })
                .addOnFailureListener(e -> {

                    Toast.makeText(
                            AddTripActivity.this,
                            "Could not load vehicles: " + e.getMessage(),
                            Toast.LENGTH_LONG
                    ).show();
                });
    }

    private void showDatePicker() {

        Calendar calendar = Calendar.getInstance();

        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog =
                new DatePickerDialog(
                        this,
                        (view, selectedYear,
                         selectedMonth,
                         selectedDay) -> {

                            String date = String.format(
                                    Locale.getDefault(),
                                    "%02d/%02d/%04d",
                                    selectedDay,
                                    selectedMonth + 1,
                                    selectedYear
                            );

                            etTripDate.setText(date);
                        },
                        year,
                        month,
                        day
                );

        datePickerDialog.show();
    }

    private void updateDistanceDisplay() {

        String distance =
                etDistance.getText().toString().trim();

        if (distance.isEmpty()) {
            tvTripDistance.setText("0 km");
        } else {
            tvTripDistance.setText(distance + " km");
        }
    }

    private void saveTrip() {

        FirebaseUser currentUser = mAuth.getCurrentUser();

        if (currentUser == null) {
            Toast.makeText(
                    this,
                    "You must be logged in",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        if (spinnerTripVehicle.getSelectedItemPosition() <= 0) {
            Toast.makeText(
                    this,
                    "Please select a vehicle",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        String startLocation =
                etStartLocation.getText().toString().trim();

        String endLocation =
                etEndLocation.getText().toString().trim();

        String distanceText =
                etDistance.getText().toString().trim();

        String date =
                etTripDate.getText().toString().trim();

        if (startLocation.isEmpty()) {
            etStartLocation.setError("Enter the start location");
            etStartLocation.requestFocus();
            return;
        }

        if (endLocation.isEmpty()) {
            etEndLocation.setError("Enter the end location");
            etEndLocation.requestFocus();
            return;
        }

        if (distanceText.isEmpty()) {
            etDistance.setError("Enter the trip distance");
            etDistance.requestFocus();
            return;
        }

        if (date.isEmpty()) {
            Toast.makeText(
                    this,
                    "Please select the trip date",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        double distanceKm;

        try {
            distanceKm = Double.parseDouble(distanceText);
        } catch (NumberFormatException e) {
            etDistance.setError("Enter a valid distance");
            etDistance.requestFocus();
            return;
        }

        if (distanceKm <= 0) {
            etDistance.setError("Distance must be greater than 0");
            etDistance.requestFocus();
            return;
        }

        int selectedPosition =
                spinnerTripVehicle.getSelectedItemPosition();

        String vehicleId =
                vehicleIds.get(selectedPosition);

        String vehicleName =
                vehicleNames.get(selectedPosition);

        String tripId =
                db.collection("trips")
                        .document()
                        .getId();

        Map<String, Object> trip = new HashMap<>();

        trip.put("tripId", tripId);
        trip.put("userId", currentUser.getUid());
        trip.put("vehicleId", vehicleId);
        trip.put("vehicleName", vehicleName);
        trip.put("startLocation", startLocation);
        trip.put("endLocation", endLocation);
        trip.put("distanceKm", distanceKm);
        trip.put("date", date);
        trip.put("createdAt", System.currentTimeMillis());

        btnSaveTrip.setEnabled(false);
        btnSaveTrip.setText("Saving...");

        db.collection("trips")
                .document(tripId)
                .set(trip)
                .addOnSuccessListener(unused -> {

                    Toast.makeText(
                            AddTripActivity.this,
                            "Trip saved successfully",
                            Toast.LENGTH_SHORT
                    ).show();

                    finish();
                })
                .addOnFailureListener(e -> {

                    btnSaveTrip.setEnabled(true);
                    btnSaveTrip.setText("Save Trip");

                    Toast.makeText(
                            AddTripActivity.this,
                            "Could not save trip: " + e.getMessage(),
                            Toast.LENGTH_LONG
                    ).show();
                });
    }

    private String safeText(String value) {

        if (value == null || value.trim().isEmpty()) {
            return "Unknown";
        }

        return value;
    }
}