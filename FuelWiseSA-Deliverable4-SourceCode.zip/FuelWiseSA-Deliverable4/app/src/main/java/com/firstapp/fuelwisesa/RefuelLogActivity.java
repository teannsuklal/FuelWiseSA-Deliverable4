package com.firstapp.fuelwisesa;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class RefuelLogActivity extends AppCompatActivity {

    private TextView tvRefuelTotalSpend;
    private TextView tvRefuelTotalLitres;
    private TextView tvRefuelCount;

    private LinearLayout refuelListContainer;
    private LinearLayout emptyRefuelCard;

    private Button btnAddRefuelFromHistory;
    private Button btnBackFromRefuelHistory;

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_refuel_log);

        // Connect XML
        tvRefuelTotalSpend =
                findViewById(R.id.tvRefuelTotalSpend);

        tvRefuelTotalLitres =
                findViewById(R.id.tvRefuelTotalLitres);

        tvRefuelCount =
                findViewById(R.id.tvRefuelCount);

        refuelListContainer =
                findViewById(R.id.refuelListContainer);

        emptyRefuelCard =
                findViewById(R.id.emptyRefuelCard);

        btnAddRefuelFromHistory =
                findViewById(R.id.btnAddRefuelFromHistory);

        btnBackFromRefuelHistory =
                findViewById(R.id.btnBackFromRefuelHistory);

        // Firebase
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        // Add Refuel
        btnAddRefuelFromHistory.setOnClickListener(v -> {

            Intent intent = new Intent(
                    RefuelLogActivity.this,
                    AddRefuelActivity.class
            );

            startActivity(intent);
        });

        // Back
        btnBackFromRefuelHistory.setOnClickListener(v ->
                finish()
        );
    }

    @Override
    protected void onResume() {
        super.onResume();

        loadRefuelHistory();
    }

    private void loadRefuelHistory() {

        FirebaseUser currentUser =
                mAuth.getCurrentUser();

        if (currentUser == null) {

            Toast.makeText(
                    this,
                    "You must be logged in",
                    Toast.LENGTH_SHORT
            ).show();

            finish();
            return;
        }

        String userId =
                currentUser.getUid();

        db.collection("refuels")
                .whereEqualTo("userId", userId)
                .get()
                .addOnSuccessListener(
                        queryDocumentSnapshots -> {

                            List<RefuelItem> refuels =
                                    new ArrayList<>();

                            double totalSpend = 0.0;
                            double totalLitres = 0.0;

                            for (QueryDocumentSnapshot document
                                    : queryDocumentSnapshots) {

                                String vehicleName =
                                        document.getString(
                                                "vehicleName"
                                        );

                                String stationName =
                                        document.getString(
                                                "stationName"
                                        );

                                String date =
                                        document.getString(
                                                "date"
                                        );

                                Double litres =
                                        document.getDouble(
                                                "litres"
                                        );

                                Double pricePerLitre =
                                        document.getDouble(
                                                "pricePerLitre"
                                        );

                                Double totalCost =
                                        document.getDouble(
                                                "totalCost"
                                        );

                                Double odometer =
                                        document.getDouble(
                                                "odometer"
                                        );

                                Long createdAt =
                                        document.getLong(
                                                "createdAt"
                                        );

                                if (litres != null) {
                                    totalLitres += litres;
                                }

                                if (totalCost != null) {
                                    totalSpend += totalCost;
                                }

                                RefuelItem item =
                                        new RefuelItem();

                                item.vehicleName =
                                        vehicleName;

                                item.stationName =
                                        stationName;

                                item.date =
                                        date;

                                item.litres =
                                        litres == null
                                                ? 0.0
                                                : litres;

                                item.pricePerLitre =
                                        pricePerLitre == null
                                                ? 0.0
                                                : pricePerLitre;

                                item.totalCost =
                                        totalCost == null
                                                ? 0.0
                                                : totalCost;

                                item.odometer =
                                        odometer == null
                                                ? 0.0
                                                : odometer;

                                item.createdAt =
                                        createdAt == null
                                                ? 0
                                                : createdAt;

                                refuels.add(item);
                            }

                            // Newest records first
                            Collections.sort(
                                    refuels,
                                    (first, second) ->
                                            Long.compare(
                                                    second.createdAt,
                                                    first.createdAt
                                            )
                            );

                            updateSummary(
                                    totalSpend,
                                    totalLitres,
                                    refuels.size()
                            );

                            displayRefuels(refuels);
                        })
                .addOnFailureListener(e -> {

                    Toast.makeText(
                            RefuelLogActivity.this,
                            "Could not load refuels: "
                                    + e.getMessage(),
                            Toast.LENGTH_LONG
                    ).show();
                });
    }

    private void updateSummary(
            double totalSpend,
            double totalLitres,
            int count
    ) {

        tvRefuelTotalSpend.setText(
                String.format(
                        Locale.getDefault(),
                        "R %.2f",
                        totalSpend
                )
        );

        tvRefuelTotalLitres.setText(
                String.format(
                        Locale.getDefault(),
                        "%.1f L total",
                        totalLitres
                )
        );

        if (count == 1) {

            tvRefuelCount.setText(
                    "1 refuel"
            );

        } else {

            tvRefuelCount.setText(
                    count + " refuels"
            );
        }
    }

    private void displayRefuels(
            List<RefuelItem> refuels
    ) {

        refuelListContainer.removeAllViews();

        if (refuels.isEmpty()) {

            emptyRefuelCard.setVisibility(
                    View.VISIBLE
            );

            return;
        }

        emptyRefuelCard.setVisibility(
                View.GONE
        );

        for (RefuelItem refuel : refuels) {

            createRefuelCard(refuel);
        }
    }

    private void createRefuelCard(
            RefuelItem refuel
    ) {

        LinearLayout card =
                new LinearLayout(this);

        card.setOrientation(
                LinearLayout.VERTICAL
        );

        card.setPadding(
                dpToPx(18),
                dpToPx(17),
                dpToPx(18),
                dpToPx(17)
        );

        card.setBackgroundResource(
                R.drawable.bg_dashboard_blue
        );

        LinearLayout.LayoutParams cardParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        cardParams.setMargins(
                0,
                0,
                0,
                dpToPx(12)
        );

        card.setLayoutParams(cardParams);

        // Vehicle
        TextView vehicleText =
                new TextView(this);

        vehicleText.setText(
                safeText(refuel.vehicleName)
        );

        vehicleText.setTextSize(17);
        vehicleText.setTextColor(
                android.graphics.Color.parseColor(
                        "#263326"
                )
        );

        vehicleText.setTypeface(
                null,
                Typeface.BOLD
        );

        card.addView(vehicleText);

        // Station
        TextView stationText =
                new TextView(this);

        stationText.setText(
                safeText(refuel.stationName)
        );

        stationText.setTextSize(14);
        stationText.setTextColor(
                android.graphics.Color.parseColor(
                        "#526566"
                )
        );

        LinearLayout.LayoutParams stationParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        stationParams.setMargins(
                0,
                dpToPx(5),
                0,
                0
        );

        stationText.setLayoutParams(
                stationParams
        );

        card.addView(stationText);

        // Litres and price
        TextView fuelText =
                new TextView(this);

        fuelText.setText(
                String.format(
                        Locale.getDefault(),
                        "%.1f L  •  R %.2f/L",
                        refuel.litres,
                        refuel.pricePerLitre
                )
        );

        fuelText.setTextSize(14);
        fuelText.setTextColor(
                android.graphics.Color.parseColor(
                        "#526566"
                )
        );

        LinearLayout.LayoutParams fuelParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        fuelParams.setMargins(
                0,
                dpToPx(7),
                0,
                0
        );

        fuelText.setLayoutParams(
                fuelParams
        );

        card.addView(fuelText);

        // Total cost
        TextView costText =
                new TextView(this);

        costText.setText(
                String.format(
                        Locale.getDefault(),
                        "R %.2f",
                        refuel.totalCost
                )
        );

        costText.setTextSize(20);
        costText.setTextColor(
                android.graphics.Color.parseColor(
                        "#263326"
                )
        );

        costText.setTypeface(
                null,
                Typeface.BOLD
        );

        LinearLayout.LayoutParams costParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        costParams.setMargins(
                0,
                dpToPx(9),
                0,
                0
        );

        costText.setLayoutParams(
                costParams
        );

        card.addView(costText);

        // Odometer
        TextView odometerText =
                new TextView(this);

        odometerText.setText(
                String.format(
                        Locale.getDefault(),
                        "Odometer: %.0f km",
                        refuel.odometer
                )
        );

        odometerText.setTextSize(13);
        odometerText.setTextColor(
                android.graphics.Color.parseColor(
                        "#788788"
                )
        );

        LinearLayout.LayoutParams odometerParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        odometerParams.setMargins(
                0,
                dpToPx(8),
                0,
                0
        );

        odometerText.setLayoutParams(
                odometerParams
        );

        card.addView(odometerText);

        // Date
        TextView dateText =
                new TextView(this);

        dateText.setText(
                "Date: "
                        + safeText(refuel.date)
        );

        dateText.setTextSize(13);
        dateText.setTextColor(
                android.graphics.Color.parseColor(
                        "#788788"
                )
        );

        LinearLayout.LayoutParams dateParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        dateParams.setMargins(
                0,
                dpToPx(3),
                0,
                0
        );

        dateText.setLayoutParams(
                dateParams
        );

        card.addView(dateText);

        refuelListContainer.addView(card);
    }

    private int dpToPx(int dp) {

        float density =
                getResources()
                        .getDisplayMetrics()
                        .density;

        return Math.round(
                dp * density
        );
    }

    private String safeText(
            String value
    ) {

        if (value == null
                || value.trim().isEmpty()) {

            return "Unknown";
        }

        return value;
    }

    private static class RefuelItem {

        String vehicleName;
        String stationName;
        String date;

        double litres;
        double pricePerLitre;
        double totalCost;
        double odometer;

        long createdAt;
    }
}